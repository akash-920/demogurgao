-- ============================================================
-- JAIN PROPERTIES AND DEVELOPERS — SUPABASE SCHEMA
-- Run this entire file in: Supabase → SQL Editor → New Query
-- ============================================================

-- 1. LEADS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS public.leads (
  id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  -- Form fields
  name             TEXT NOT NULL,
  phone            TEXT NOT NULL,
  plot_location    TEXT NOT NULL,
  plot_size        TEXT NOT NULL,
  package_interest TEXT NOT NULL,
  message          TEXT,

  -- CRM metadata (managed by admin)
  status           TEXT NOT NULL DEFAULT 'new'
                     CHECK (status IN ('new','called','site_visit_scheduled','converted','not_interested')),
  admin_notes      TEXT,

  -- Source tracking
  source           TEXT NOT NULL DEFAULT 'website_popup',
  utm_source       TEXT,
  utm_medium       TEXT,
  utm_campaign     TEXT
);

-- 2. INDEXES for fast queries
-- ============================================================
CREATE INDEX IF NOT EXISTS leads_created_at_idx ON public.leads (created_at DESC);
CREATE INDEX IF NOT EXISTS leads_status_idx     ON public.leads (status);
CREATE INDEX IF NOT EXISTS leads_phone_idx      ON public.leads (phone);

-- 3. ROW LEVEL SECURITY
-- ============================================================
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Public anon key: INSERT only (no reads)
CREATE POLICY "Anyone can submit a lead"
  ON public.leads FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Authenticated (admin via Supabase Auth, if added later) can read & update
CREATE POLICY "Authenticated can read leads"
  ON public.leads FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Authenticated can update leads"
  ON public.leads FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

-- Note: Service role key (used in Admin CRM) bypasses RLS entirely.

-- 4. LEAD STATS VIEW
-- ============================================================
CREATE OR REPLACE VIEW public.lead_stats AS
SELECT
  COUNT(*)                                                           AS total_leads,
  COUNT(*) FILTER (WHERE DATE(created_at AT TIME ZONE 'Asia/Kolkata') = CURRENT_DATE) AS today_leads,
  COUNT(*) FILTER (WHERE status = 'new')                            AS new_leads,
  COUNT(*) FILTER (WHERE status = 'called')                         AS called_leads,
  COUNT(*) FILTER (WHERE status = 'site_visit_scheduled')           AS site_visit_leads,
  COUNT(*) FILTER (WHERE status = 'converted')                      AS converted_leads,
  COUNT(*) FILTER (WHERE status = 'not_interested')                 AS not_interested_leads,
  COUNT(*) FILTER (WHERE package_interest ILIKE '%classic%')        AS classic_leads,
  COUNT(*) FILTER (WHERE package_interest ILIKE '%pure%')           AS pure_leads,
  COUNT(*) FILTER (WHERE package_interest ILIKE '%premium%')        AS premium_leads
FROM public.leads;

-- ============================================================
-- DONE! Now get your API keys:
-- Supabase Dashboard → Project Settings → API
--
--   VITE_SUPABASE_URL         = Project URL
--   VITE_SUPABASE_ANON_KEY    = anon / public key
--   VITE_SUPABASE_SERVICE_KEY = service_role key (keep SECRET)
--   VITE_ADMIN_PASSWORD       = choose any password for CRM
--
-- Copy .env.example to .env and paste the values above.
-- ============================================================
