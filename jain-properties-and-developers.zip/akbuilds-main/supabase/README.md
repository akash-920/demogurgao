# Supabase Setup Guide - Jain Properties and Developers

## Step 1: Create Supabase Project
1. Go to https://supabase.com -> New Project
2. Name: akbuilds, pick strong DB password
3. Region: Southeast Asia (Singapore - closest to India)
4. Wait ~2 minutes for provisioning

## Step 2: Run the Schema
1. Supabase Dashboard -> SQL Editor -> New Query
2. Paste entire contents of schema.sql
3. Click Run - you should see: table leads, 3 indexes, RLS policies, lead_stats view

## Step 3: Get API Keys
Go to Project Settings -> API:

- VITE_SUPABASE_URL       = Project URL
- VITE_SUPABASE_ANON_KEY  = anon / public key (safe for browser)
- VITE_SUPABASE_SERVICE_KEY = service_role key (KEEP SECRET - admin only)

## Step 4: Create .env File
Copy .env.example to .env and fill in your keys:

  VITE_SUPABASE_URL=https://your-project.supabase.co
  VITE_SUPABASE_ANON_KEY=eyJ...
  VITE_SUPABASE_SERVICE_KEY=eyJ...
  VITE_ADMIN_PASSWORD=YourStrongPassword123

NEVER commit .env to git (it is already in .gitignore).

## Step 5: Test
Run: npm run dev
- Submit the lead form -> check Supabase Table Editor -> leads
- Visit /admin -> login -> see CRM dashboard

## Architecture

Website$f = 'src/App.tsx'
$lines = Get-Content $f
$lines[0..94] | Out-File $f -Encoding utf8
'Done: trimmed to ' + 95
 -> submitLead() -> Supabase (anon key, INSERT only)
                                 -> WhatsApp opens

Admin at /admin -> AdminLogin.tsx -> password check
               -> AdminDashboard.tsx -> adminSupabase (service role, full access)

## Security Notes
- Anon key in browser: RLS prevents reads, INSERT only
- Service key in admin: protected by client-side password (fine for internal use)
- For production: move admin to a server-side API route / Next.js route handler
