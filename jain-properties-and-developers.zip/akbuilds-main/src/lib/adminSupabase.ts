import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const serviceKey  = import.meta.env.VITE_SUPABASE_SERVICE_KEY as string;

// Admin client — service role key bypasses RLS for full access
// Used ONLY inside the password-gated Admin CRM panel
export const adminSupabase = createClient(supabaseUrl || '', serviceKey || '', {
  auth: { autoRefreshToken: false, persistSession: false },
});

// ─── Types ─────────────────────────────────────────────────────────────────────

export type LeadStatus =
  | 'new'
  | 'called'
  | 'site_visit_scheduled'
  | 'converted'
  | 'not_interested';

export interface Lead {
  id: string;
  created_at: string;
  name: string;
  phone: string;
  plot_location: string;
  plot_size: string;
  package_interest: string;
  message?: string;
  status: LeadStatus;
  admin_notes?: string;
  source: string;
}

export interface LeadStats {
  total_leads: number;
  today_leads: number;
  new_leads: number;
  called_leads: number;
  site_visit_leads: number;
  converted_leads: number;
  not_interested_leads: number;
  classic_leads: number;
  pure_leads: number;
  premium_leads: number;
}

// ─── Status Metadata ───────────────────────────────────────────────────────────

export const STATUS_LABELS: Record<LeadStatus, string> = {
  new:                   'New',
  called:                'Called',
  site_visit_scheduled:  'Site Visit',
  converted:             'Converted',
  not_interested:        'Not Interested',
};

export const STATUS_COLORS: Record<LeadStatus, string> = {
  new:                   'bg-blue-100 text-blue-800 border-blue-200',
  called:                'bg-amber-100 text-amber-800 border-amber-200',
  site_visit_scheduled:  'bg-purple-100 text-purple-800 border-purple-200',
  converted:             'bg-green-100 text-green-800 border-green-200',
  not_interested:        'bg-red-100 text-red-800 border-red-200',
};

// ─── Admin Queries ─────────────────────────────────────────────────────────────

export async function fetchAllLeads(): Promise<Lead[]> {
  const { data, error } = await adminSupabase
    .from('leads')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw new Error(error.message);
  return (data ?? []) as Lead[];
}

export async function updateLeadStatus(
  id: string,
  status: LeadStatus,
  adminNotes?: string
): Promise<void> {
  const payload: Partial<Lead> = { status };
  if (adminNotes !== undefined) payload.admin_notes = adminNotes;

  const { error } = await adminSupabase
    .from('leads')
    .update(payload)
    .eq('id', id);

  if (error) throw new Error(error.message);
}

export async function fetchLeadStats(): Promise<LeadStats> {
  const { data, error } = await adminSupabase
    .from('lead_stats')
    .select('*')
    .single();

  if (error) throw new Error(error.message);
  return data as LeadStats;
}
