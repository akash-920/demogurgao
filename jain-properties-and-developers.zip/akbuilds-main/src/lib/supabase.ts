import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    '[Jain Properties and Developers] Supabase env vars missing. ' +
    'Copy .env.example to .env and fill in your Supabase keys.'
  );
}

// Public client — anon key, INSERT only (protected by RLS)
export const supabase = createClient(supabaseUrl || '', supabaseAnonKey || '');

// ─── Types ─────────────────────────────────────────────────────────────────────

export interface LeadInsert {
  name: string;
  phone: string;
  plot_location: string;
  plot_size: string;
  package_interest: string;
  message?: string;
  source?: string;
}

// ─── Lead Submission ───────────────────────────────────────────────────────────

export async function submitLead(
  data: LeadInsert
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.from('leads').insert([
      {
        name: data.name,
        phone: data.phone,
        plot_location: data.plot_location,
        plot_size: data.plot_size,
        package_interest: data.package_interest,
        message: data.message ?? null,
        source: data.source ?? 'website_popup',
      },
    ]);

    if (error) {
      console.error('[Supabase] Lead insert error:', error.message);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error occurred';
    console.error('[Supabase] Unexpected error:', message);
    return { success: false, error: message };
  }
}
