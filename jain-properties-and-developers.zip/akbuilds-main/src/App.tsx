import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Outlet } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { LeadModal } from './components/LeadModal';
import { Home } from './pages/Home';
import { Services } from './pages/Services';
import { Process } from './pages/Process';
import { Packages } from './pages/Packages';
import { Contact } from './pages/Contact';
import { AdminLogin } from './pages/admin/AdminLogin';
import { AdminDashboard } from './pages/admin/AdminDashboard';

// ─── ScrollToTop: resets scroll on every route change ─────────────────────────
const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
};

// ─── Public Layout: Navbar + Footer + LeadModal wrapper ───────────────────────
interface PublicLayoutProps {
  onOpenConsultation: (pkg?: string) => void;
  isLeadModalOpen: boolean;
  onCloseModal: () => void;
  selectedPackage?: string;
}

const PublicLayout: React.FC<PublicLayoutProps> = ({
  onOpenConsultation, isLeadModalOpen, onCloseModal, selectedPackage,
}) => (
  <div className="min-h-screen flex flex-col bg-[#F7F5EF] font-sans antialiased text-[#202622]">
    <Navbar onOpenConsultation={() => onOpenConsultation()} />
    <main className="flex-1">
      <Outlet />
    </main>
    <Footer onOpenConsultation={() => onOpenConsultation()} />
    <LeadModal
      isOpen={isLeadModalOpen}
      onClose={onCloseModal}
      initialPackage={selectedPackage}
    />
  </div>
);

// ─── App ───────────────────────────────────────────────────────────────────────
export function App() {
  const [isLeadModalOpen, setIsLeadModalOpen]     = useState(false);
  const [selectedPackage, setSelectedPackage]     = useState<string | undefined>(undefined);

  // Auto-open popup on first visit
  useEffect(() => {
    const timer = setTimeout(() => setIsLeadModalOpen(true), 600);
    return () => clearTimeout(timer);
  }, []);

  const handleOpenConsultation = (packageName?: string) => {
    setSelectedPackage(packageName);
    setIsLeadModalOpen(true);
  };

  const handleCloseModal = () => setIsLeadModalOpen(false);

  return (
    <Router>
      <ScrollToTop />
      <Routes>
        {/* ── Admin (no Navbar/Footer/Modal) ── */}
        <Route path="/admin"           element={<AdminLogin />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />

        {/* ── Public pages (Navbar + Footer + Modal) ── */}
        <Route
          element={
            <PublicLayout
              onOpenConsultation={handleOpenConsultation}
              isLeadModalOpen={isLeadModalOpen}
              onCloseModal={handleCloseModal}
              selectedPackage={selectedPackage}
            />
          }
        >
          <Route index element={<Home onOpenConsultation={handleOpenConsultation} />} />
          <Route path="services" element={<Services onOpenConsultation={handleOpenConsultation} />} />
          <Route path="process"  element={<Process onOpenConsultation={handleOpenConsultation} />} />
          <Route path="packages" element={<Packages onOpenConsultation={handleOpenConsultation} />} />
          <Route path="contact"  element={<Contact />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;

