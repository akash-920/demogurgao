import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Phone, Menu, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface NavbarProps {
  onOpenConsultation: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenConsultation }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Our Services', path: '/services' },
    { name: 'Our Process', path: '/process' },
    { name: 'Packages', path: '/packages' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <>
      {/* Top micro bar with click-to-call details & service coverage */}
      <div className="bg-[#173B35] text-[#F7F5EF] text-xs py-1.5 px-4 border-b border-[#E7B86A]/20 hidden sm:block">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4 text-stone-300">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#E7B86A]" />
              Turnkey Construction & Interior Solutions
            </span>
            <span className="text-[#E7B86A]">•</span>
            <span>Serving: Delhi | your city | Noida | nearby locations</span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="tel:+919810155668"
              className="flex items-center gap-1.5 hover:text-[#E7B86A] transition-colors"
            >
              <Phone className="w-3 h-3 text-[#E7B86A]" />
              <span className="font-medium">Our Team: +91 90000 00000</span>
            </a>
            <span className="text-stone-600">|</span>
            <a
              href="tel:+918447219897"
              className="flex items-center gap-1.5 hover:text-[#E7B86A] transition-colors"
            >
              <span className="font-medium">Property Consultant: +91 90000 00000</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Sticky Navbar */}
      <header
        className={`sticky top-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#F7F5EF]/95 backdrop-blur-md shadow-md py-3 border-b border-[#E7B86A]/30'
            : 'bg-[#F7F5EF] py-4 border-b border-[#E7DFD5]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="outline-none focus:ring-2 focus:ring-[#E7B86A] rounded-md p-0.5">
            <BrandLogo size="md" />
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => {
              const active = isActive(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-sm font-semibold tracking-wide transition-all relative py-1 ${
                    active
                      ? 'text-[#214C43]'
                      : 'text-stone-700 hover:text-[#214C43]'
                  }`}
                >
                  {link.name}
                  {active && (
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#E7B86A] rounded-full" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right CTA Actions */}
          <div className="hidden lg:flex items-center gap-4">
            {/* Direct Click-to-call phone pill */}
            <a
              href="tel:+919810155668"
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#214C43]/5 border border-[#214C43]/15 text-[#214C43] text-xs font-semibold hover:bg-[#214C43]/10 transition-colors"
              title="Click to call Our Team"
            >
              <Phone className="w-3.5 h-3.5 text-[#E7B86A]" />
              <span>+91 90000 00000</span>
            </a>

            {/* Consultation CTA */}
            <button
              onClick={onOpenConsultation}
              className="px-5 py-2.5 rounded-lg bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] text-xs uppercase font-bold tracking-wider shadow-md hover:shadow-lg transition-all duration-200 border border-[#E7B86A]/40 flex items-center gap-2 cursor-pointer"
            >
              <span>Get Consultation</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#E7B86A]" />
            </button>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex items-center gap-2 lg:hidden">
            <a
              href="tel:+919810155668"
              className="p-2 rounded-lg bg-[#214C43] text-[#F7F5EF] shadow-sm flex items-center justify-center"
              aria-label="Call Jain Properties and Developers"
            >
              <Phone className="w-4 h-4 text-[#E7B86A]" />
            </a>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#214C43] hover:bg-[#214C43]/10 transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex flex-col bg-[#F7F5EF]">
          <div className="p-4 border-b border-[#E7DFD5] flex items-center justify-between bg-[#173B35] text-[#F7F5EF]">
            <BrandLogo variant="light" size="sm" />
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded-full bg-[#214C43] text-[#F7F5EF] hover:bg-[#E7B86A] hover:text-[#214C43] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <nav className="flex flex-col gap-4">
              {navLinks.map((link) => {
                const active = isActive(link.path);
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`text-lg font-serif font-bold p-3 rounded-lg transition-colors flex items-center justify-between ${
                      active
                        ? 'bg-[#214C43] text-[#F7F5EF]'
                        : 'text-stone-800 hover:bg-stone-100'
                    }`}
                  >
                    <span>{link.name}</span>
                    <ArrowRight className="w-4 h-4 opacity-60" />
                  </Link>
                );
              })}
            </nav>

            <div className="pt-6 border-t border-stone-200 space-y-4">
              <div className="bg-[#214C43]/5 p-4 rounded-xl border border-[#214C43]/15 space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-[#214C43]">
                  Direct Click-to-Call Contact
                </div>
                <a
                  href="tel:+919810155668"
                  className="flex items-center gap-3 text-sm font-semibold text-[#214C43] hover:underline"
                >
                  <Phone className="w-4 h-4 text-[#E7B86A]" />
                  <span>Our Team: +91 90000 00000</span>
                </a>
                <a
                  href="tel:+918447219897"
                  className="flex items-center gap-3 text-sm font-semibold text-[#214C43] hover:underline"
                >
                  <Phone className="w-4 h-4 text-[#E7B86A]" />
                  <span>Property Consultant: +91 90000 00000</span>
                </a>
              </div>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenConsultation();
                }}
                className="w-full py-3.5 px-6 rounded-lg bg-[#214C43] text-[#F7F5EF] font-bold text-sm tracking-wider uppercase shadow-md flex items-center justify-center gap-2"
              >
                <span>Get Free Consultation</span>
                <ArrowRight className="w-4 h-4 text-[#E7B86A]" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
