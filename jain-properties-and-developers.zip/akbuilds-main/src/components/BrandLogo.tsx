import React from 'react';

interface BrandLogoProps {
  variant?: 'light' | 'dark' | 'burgundy';
  showTagline?: boolean;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'dark',
  showTagline = false,
  className = '',
  size = 'md'
}) => {
  const isLight = variant === 'light';

  // Transparent logo variants generated from uploaded image
  const logoSrc = isLight ? '/logo-jain.svg' : '/logo-jain.svg';

  const logoHeightClasses = {
    sm: 'h-8 sm:h-9',
    md: 'h-10 sm:h-12',
    lg: 'h-12 sm:h-16'
  }[size];

  return (
    <div className={`flex flex-col items-start group cursor-pointer select-none ${className}`}>
      {/* Clean Logo Image */}
      <img 
        src={logoSrc} 
        alt="JAIN PROPERTIES AND DEVELOPERS" 
        className={`${logoHeightClasses} w-auto object-contain transition-transform duration-300 group-hover:scale-102`}
        loading="eager"
      />
      
      {showTagline && (
        <span className={`font-sans tracking-widest uppercase text-[9px] sm:text-[10px] font-bold mt-1 ${
          isLight ? 'text-[#E7B86A]' : 'text-[#72202E]'
        }`}>
          Involved at Every Step
        </span>
      )}
    </div>
  );
};
