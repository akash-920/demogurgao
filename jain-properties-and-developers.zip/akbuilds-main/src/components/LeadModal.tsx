import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, Send, Phone, MapPin, CheckCircle2, ShieldCheck, Sparkles,
  MessageSquare, AlertCircle, Loader2,
} from 'lucide-react';
import { submitLead } from '../lib/supabase';

// -----------------------------------------------------------------------------
// Types
// -----------------------------------------------------------------------------

interface FormData {
  name: string;
  phone: string;
  plotLocation: string;
  plotSize: string;
  packageInterest: string;
}

interface FieldErrors {
  name?: string;
  phone?: string;
  plotLocation?: string;
  plotSize?: string;
  packageInterest?: string;
}

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPackage?: string;
}

// -----------------------------------------------------------------------------
// Validation Rules
// -----------------------------------------------------------------------------

const PHONE_REGEX = /^[6-9]\d{9}$/; // Indian 10-digit mobile number

function validate(data: FormData): FieldErrors {
  const errors: FieldErrors = {};

  // Name: required, min 2 chars, letters/spaces/dots only
  const trimName = data.name.trim();
  if (!trimName) {
    errors.name = 'Full name is required.';
  } else if (trimName.length < 2) {
    errors.name = 'Name must be at least 2 characters.';
  } else if (!/^[A-Za-z\s.'-]{2,60}$/.test(trimName)) {
    errors.name = 'Name can only contain letters, spaces, dots, or hyphens.';
  }

  // Phone: required, exactly 10 digits, starts with 6-9
  const rawPhone = data.phone.replace(/[\s\-+()]/g, '');
  const phone = rawPhone.startsWith('91') && rawPhone.length === 12
    ? rawPhone.slice(2)
    : rawPhone;
  if (!phone) {
    errors.phone = 'Phone number is required.';
  } else if (!PHONE_REGEX.test(phone)) {
    errors.phone = 'Enter a valid 10-digit Indian mobile number (starts with 6-9).';
  }

  // Plot Location: required, min 5 chars
  const trimLoc = data.plotLocation.trim();
  if (!trimLoc) {
    errors.plotLocation = 'Plot location is required.';
  } else if (trimLoc.length < 5) {
    errors.plotLocation = 'Please enter a more specific location (min 5 chars).';
  }

  // Plot Size: required
  const trimSize = data.plotSize.trim();
  if (!trimSize) {
    errors.plotSize = 'Plot size is required.';
  }

  // Package: required
  if (!data.packageInterest) {
    errors.packageInterest = 'Please select a package preference.';
  }

  return errors;
}

function hasErrors(errors: FieldErrors): boolean {
  return Object.values(errors).some(Boolean);
}

// -----------------------------------------------------------------------------
// Field Error Component
// -----------------------------------------------------------------------------

const FieldError: React.FC<{ message?: string }> = ({ message }) =>
  message ? (
    <motion.p
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-1 flex items-center gap-1 text-xs text-red-600"
    >
      <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
      {message}
    </motion.p>
  ) : null;

// -----------------------------------------------------------------------------
// Main Component
// -----------------------------------------------------------------------------

export const LeadModal: React.FC<LeadModalProps> = ({ isOpen, onClose, initialPackage }) => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    phone: '',
    plotLocation: '',
    plotSize: '',
    packageInterest: initialPackage || '',
  });

  const [errors, setErrors]         = useState<FieldErrors>({});
  const [touched, setTouched]       = useState<Partial<Record<keyof FormData, boolean>>>({});
  const [submitted, setSubmitted]   = useState(false);
  const [loading, setLoading]       = useState(false);
  const [dbError, setDbError]       = useState<string | null>(null);
  const [whatsappUrl, setWhatsappUrl] = useState('');

  // Sync initialPackage when prop changes
  useEffect(() => {
    if (initialPackage) {
      setFormData(prev => ({ ...prev, packageInterest: initialPackage }));
    }
  }, [initialPackage]);

  // Reset form when modal opens
  useEffect(() => {
    if (isOpen) {
      setErrors({});
      setTouched({});
      setSubmitted(false);
      setDbError(null);
    }
  }, [isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const newData = { ...formData, [name]: value };
    setFormData(newData);

    // Live-validate only if the field has been touched
    if (touched[name as keyof FormData]) {
      const fieldErrors = validate(newData);
      setErrors(prev => ({ ...prev, [name]: fieldErrors[name as keyof FieldErrors] }));
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name } = e.target;
    setTouched(prev => ({ ...prev, [name]: true }));
    const fieldErrors = validate(formData);
    setErrors(prev => ({ ...prev, [name]: fieldErrors[name as keyof FieldErrors] }));
  };

  const buildWhatsAppUrl = (data: FormData): string => {
    const lines = [
      `*New Consultation Request - Jain Properties and Developers*`,
      ``,
      `- *Name:* ${data.name.trim()}`,
      `- *Phone:* ${data.phone.trim()}`,
      `- *Plot Location:* ${data.plotLocation.trim()}`,
      `- *Plot Size:* ${data.plotSize.trim()}`,
      `- *Package Interest:* ${data.packageInterest}`,
      ``,
      `Please connect with me for a site visit and detailed estimate.`,
    ];
    return `https://wa.me/919810155668?text=${encodeURIComponent(lines.join('\n'))}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setDbError(null);

    // Mark all fields as touched and validate
    const allTouched = Object.keys(formData).reduce(
      (acc, k) => ({ ...acc, [k]: true }),
      {} as Record<keyof FormData, boolean>
    );
    setTouched(allTouched);

    const fieldErrors = validate(formData);
    setErrors(fieldErrors);

    if (hasErrors(fieldErrors)) return;

    setLoading(true);

    // Normalize phone: strip non-digits, remove leading 91 if 12-digit
    const rawPhone = formData.phone.replace(/[\s\-+()]/g, '');
    const normalizedPhone =
      rawPhone.startsWith('91') && rawPhone.length === 12 ? rawPhone.slice(2) : rawPhone;

    // 1. Save to Supabase
    const result = await submitLead({
      name:             formData.name.trim(),
      phone:            normalizedPhone,
      plot_location:    formData.plotLocation.trim(),
      plot_size:        formData.plotSize.trim(),
      package_interest: formData.packageInterest,
      source:           'website_popup',
    });

    setLoading(false);

    if (!result.success) {
      // Don't block the user - show a soft warning but still proceed to WhatsApp
      setDbError('Details saved with a warning. Proceeding to WhatsApp.');
      console.error('[LeadModal] DB save failed:', result.error);
    }

    // 2. Build WhatsApp URL and redirect
    const waUrl = buildWhatsAppUrl(formData);
    setWhatsappUrl(waUrl);

    // Mark session so popup doesn't show again
    sessionStorage.setItem('hasSubmittedLead', 'true');

    setSubmitted(true);
    window.open(waUrl, '_blank');
  };

  const handleResetAndClose = () => {
    setSubmitted(false);
    setFormData({ name: '', phone: '', plotLocation: '', plotSize: '', packageInterest: '' });
    setErrors({});
    setTouched({});
    setDbError(null);
    onClose();
  };

  // -----------------------------------------------------------------------------
  // Input class helpers
  // -----------------------------------------------------------------------------

  const inputClass = (field: keyof FormData) =>
    `w-full px-4 py-3 bg-white border rounded-lg text-sm text-stone-900 
     focus:outline-none focus:ring-1 transition-all shadow-xs
     ${errors[field] && touched[field]
      ? 'border-red-400 focus:border-red-500 focus:ring-red-300'
      : 'border-stone-300 focus:border-[#214C43] focus:ring-[#214C43]'}`;

  const iconInputClass = (field: keyof FormData) =>
    `w-full pl-10 pr-4 py-3 bg-white border rounded-lg text-sm text-stone-900
     focus:outline-none focus:ring-1 transition-all shadow-xs
     ${errors[field] && touched[field]
      ? 'border-red-400 focus:border-red-500 focus:ring-red-300'
      : 'border-stone-300 focus:border-[#214C43] focus:ring-[#214C43]'}`;

  // -----------------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------------

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 overflow-y-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#173B35]/80 backdrop-blur-md"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative w-full max-w-xl bg-[#F7F5EF] rounded-xl shadow-2xl border border-[#E7B86A]/40 overflow-hidden z-10 my-auto"
          >
            {/* Header */}
            <div className="relative bg-blueprint p-6 md:p-8 text-[#F7F5EF] border-b border-[#E7B86A]/30">
              <button
                onClick={onClose}
                type="button"
                className="absolute top-4 right-4 p-2 rounded-full bg-[#3B0F1A]/80 hover:bg-[#E7B86A] text-[#F7F5EF] hover:text-[#214C43] transition-all duration-200 shadow-md border border-[#E7B86A]/40 focus:outline-none focus:ring-2 focus:ring-[#E7B86A]"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-[#E7B86A] text-xs font-semibold tracking-widest uppercase mb-1">
                <Sparkles className="w-4 h-4" />
                <span>Jain Properties and Developers Lead Desk</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#F7F5EF] tracking-wide">
                Let's Build Your Dream Space
              </h2>
              <p className="text-stone-300 text-sm mt-1 max-w-md font-light leading-relaxed">
                Tell us about your project and connect with our property team on WhatsApp.
              </p>
            </div>

            {/* Body */}
            <div className="p-6 md:p-8 bg-[#F7F5EF]">
              {submitted ? (
                /* Success State */
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-6 space-y-4"
                >
                  <div className="w-16 h-16 bg-[#214C43]/10 rounded-full flex items-center justify-center mx-auto border border-[#E7B86A]/50">
                    <CheckCircle2 className="w-10 h-10 text-[#E7B86A]" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold text-[#214C43]">
                    Redirecting to WhatsApp...
                  </h3>
                  <p className="text-stone-700 text-sm max-w-sm mx-auto leading-relaxed">
                    Thank you, <span className="font-semibold text-[#214C43]">{formData.name}</span>.
                    Your project details for{' '}
                    <span className="font-semibold">{formData.plotLocation || 'your site'}</span>{' '}
                    are being sent to{' '}
                    <span className="font-semibold">+91 90000 00000</span> on WhatsApp.
                  </p>

                  {dbError && (
                    <p className="text-xs text-amber-600 bg-amber-50 border border-amber-200 rounded-lg px-4 py-2">
                      {dbError}
                    </p>
                  )}

                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={whatsappUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold text-xs uppercase tracking-wider rounded-lg shadow-md transition-all inline-flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4 fill-current" />
                      <span>Open WhatsApp Chat Now</span>
                    </a>
                    <button
                      onClick={handleResetAndClose}
                      className="px-6 py-3 bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] text-xs font-semibold uppercase tracking-wider rounded-lg shadow-md transition-all border border-[#E7B86A]/40"
                    >
                      Close Window
                    </button>
                  </div>
                </motion.div>
              ) : (
                /* Form */
                <form onSubmit={handleSubmit} noValidate className="space-y-4">
                  {/* Name */}
                  <div>
                    <label htmlFor="lm-name" className="block text-xs font-bold uppercase tracking-wider text-[#214C43] mb-1">
                      Full Name <span className="text-red-600">*</span>
                    </label>
                    <input
                      id="lm-name" type="text" name="name" autoComplete="name"
                      placeholder="e.g. Our Team"
                      value={formData.name}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      className={inputClass('name')}
                    />
                    <FieldError message={touched.name ? errors.name : undefined} />
                  </div>

                  {/* Phone */}
                  <div>
                    <label htmlFor="lm-phone" className="block text-xs font-bold uppercase tracking-wider text-[#214C43] mb-1">
                      Phone Number <span className="text-red-600">*</span>
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                        <Phone className="w-4 h-4 text-[#E7B86A]" />
                      </div>
                      <input
                        id="lm-phone" type="tel" name="phone" autoComplete="tel"
                        placeholder="10-digit mobile number"
                        value={formData.phone}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        maxLength={13}
                        className={iconInputClass('phone')}
                      />
                    </div>
                    <FieldError message={touched.phone ? errors.phone : undefined} />
                  </div>

                  {/* Plot Location + Plot Size */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="lm-location" className="block text-xs font-bold uppercase tracking-wider text-[#214C43] mb-1">
                        Plot Location <span className="text-red-600">*</span>
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                          <MapPin className="w-4 h-4 text-[#E7B86A]" />
                        </div>
                        <input
                          id="lm-location" type="text" name="plotLocation"
                          placeholder="e.g. Your location"
                          value={formData.plotLocation}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          className={iconInputClass('plotLocation')}
                        />
                      </div>
                      <FieldError message={touched.plotLocation ? errors.plotLocation : undefined} />
                    </div>

                    <div>
                      <label htmlFor="lm-size" className="block text-xs font-bold uppercase tracking-wider text-[#214C43] mb-1">
                        Plot Size <span className="text-red-600">*</span>
                      </label>
                      <input
                        id="lm-size" type="text" name="plotSize"
                        placeholder="e.g. 200 Sq. Yd."
                        value={formData.plotSize}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        className={inputClass('plotSize')}
                      />
                      <FieldError message={touched.plotSize ? errors.plotSize : undefined} />
                    </div>
                  </div>

                  {/* Package Interest */}
                  <div>
                    <label htmlFor="lm-package" className="block text-xs font-bold uppercase tracking-wider text-[#214C43] mb-1">
                      Package Interest <span className="text-red-600">*</span>
                    </label>
                    <select
                      id="lm-package" name="packageInterest"
                      value={formData.packageInterest}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      className={inputClass('packageInterest')}
                    >
                      <option value="">-- Select Package Preference --</option>
                      <option value="Classic Package (Rs. 2,200/sq.ft)">CLASSIC Package - Rs. 2,200 + GST / sq.ft</option>
                      <option value="Pure Package (Rs. 2,600/sq.ft)">PURE Package - Rs. 2,600 + GST / sq.ft</option>
                      <option value="Premium Package (Rs. 3,000/sq.ft)">PREMIUM Package - Rs. 3,000 + GST / sq.ft</option>
                      <option value="Bespoke Custom Build">Bespoke / Custom Architectural Consultation</option>
                    </select>
                    <FieldError message={touched.packageInterest ? errors.packageInterest : undefined} />
                  </div>

                  {/* Submit */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full py-3.5 px-6 bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] font-semibold text-sm rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center gap-2 border border-[#E7B86A]/40 group cursor-pointer disabled:opacity-70"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Saving & Connecting...</span>
                        </>
                      ) : (
                        <>
                          <span>Get Free Consultation on WhatsApp</span>
                          <Send className="w-4 h-4 text-[#E7B86A] group-hover:translate-x-1 transition-transform" />
                        </>
                      )}
                    </button>
                  </div>

                  <div className="flex items-center justify-center gap-2 text-xs text-stone-500 pt-1">
                    <ShieldCheck className="w-4 h-4 text-[#E7B86A]" />
                    <span>Direct WhatsApp redirect to +91 90000 00000 - All fields required</span>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

