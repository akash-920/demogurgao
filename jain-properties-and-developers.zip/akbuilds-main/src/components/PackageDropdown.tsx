import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ShieldCheck, Check } from 'lucide-react';
import { PackageTier } from '../types';

export interface PackageDropdownProps {
  packageTiers: PackageTier[];
  selectedTierId: string;
  onChange: (tierId: string) => void;
}

export const PackageDropdown: React.FC<PackageDropdownProps> = ({
  packageTiers,
  selectedTierId,
  onChange
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedTier = packageTiers.find(p => p.id === selectedTierId) || packageTiers[1];

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative w-full" ref={dropdownRef}>
      {/* Dropdown Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full px-4 py-3 bg-[#4B1120] text-[#F8F6F2] rounded-[20px] border border-[#C8A45D] shadow-lg flex items-center justify-between transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#C8A45D]/50 hover:bg-[#214C43] ${
          isOpen ? 'ring-2 ring-[#C8A45D]/50 border-[#C8A45D]' : ''
        }`}
      >
        <div className="flex items-center gap-3 text-left overflow-hidden">
          <div className="p-2 rounded-xl bg-[#173B35] text-[#C8A45D] border border-[#C8A45D]/30 shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-serif font-bold text-sm text-[#F8F6F2] truncate">
              {selectedTier.name} Package
            </span>
            <span className="text-[11px] font-semibold text-[#C8A45D] tracking-wider uppercase">
              ₹{selectedTier.price.toLocaleString('en-IN')} + GST / sq.ft
            </span>
          </div>
        </div>

        <div className="p-1 rounded-full text-[#C8A45D] shrink-0 ml-2">
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.25 }}
          >
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </div>
      </button>

      {/* Dropdown Options Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="absolute left-0 right-0 top-full mt-2 z-50 bg-[#4B1120] border border-[#C8A45D] rounded-[20px] shadow-2xl overflow-hidden p-2 space-y-1.5 backdrop-blur-md"
          >
            {packageTiers.map((tier) => {
              const isSelected = selectedTierId === tier.id;

              return (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => {
                    onChange(tier.id);
                    setIsOpen(false);
                  }}
                  className={`w-full p-3.5 rounded-xl transition-all duration-150 text-left flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-[#C8A45D] text-[#173B35] shadow-md font-bold'
                      : 'bg-transparent text-[#F8F6F2] hover:bg-[#214C43] hover:text-[#F8F6F2]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Custom Circular Check Icon / Radio Selector */}
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                        isSelected
                          ? 'border-[#173B35] bg-[#173B35] text-[#C8A45D]'
                          : 'border-[#C8A45D] bg-transparent'
                      }`}
                    >
                      {isSelected && <div className="w-2 h-2 rounded-full bg-[#C8A45D]" />}
                    </div>

                    <div className="flex flex-col min-w-0">
                      <span className={`font-serif font-bold text-sm ${isSelected ? 'text-[#173B35]' : 'text-[#F8F6F2]'}`}>
                        {tier.name} Package
                      </span>
                      <span className={`text-[11px] font-semibold ${isSelected ? 'text-[#4B1120]' : 'text-[#C8A45D]'}`}>
                        ₹{tier.price.toLocaleString('en-IN')} + GST / sq.ft
                      </span>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="p-1 rounded-full bg-[#173B35] text-[#C8A45D] shrink-0 ml-2">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
