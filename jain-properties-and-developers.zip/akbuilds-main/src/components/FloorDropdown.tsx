import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Layers3, Check } from 'lucide-react';

export interface FloorOption {
  id: string;
  title: string;
  code: string;
  multiplier: number;
}

export const FLOOR_OPTIONS: FloorOption[] = [
  { id: 'g', title: 'Ground Floor Only', code: 'G', multiplier: 1 },
  { id: 'g1', title: 'Ground + 1 Floor', code: 'G+1', multiplier: 2 },
  { id: 'g2', title: 'Ground + 2 Floors', code: 'G+2', multiplier: 3 },
  { id: 'g3', title: 'Ground + 3 Floors', code: 'G+3', multiplier: 4 },
  { id: 'g4', title: 'Ground + 4 Floors', code: 'G+4', multiplier: 5 },
  { id: 'bg3', title: 'Basement + Ground + 3 Floors', code: 'B+G+3', multiplier: 5 },
  { id: 'sg3', title: 'Stilt + Ground + 3 Floors', code: 'S+G+3', multiplier: 5 },
  { id: 'bsg3', title: 'Basement + Stilt + Ground + 3 Floors', code: 'B+S+G+3', multiplier: 6 }
];

interface FloorDropdownProps {
  selectedOption: FloorOption;
  onChange: (option: FloorOption) => void;
}

export const FloorDropdown: React.FC<FloorDropdownProps> = ({ selectedOption, onChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative w-full" ref={dropdownRef}>
      {/* Dropdown Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full px-4 py-3 bg-[#4B1120] text-[#F8F6F2] rounded-[20px] border border-[#C8A45D] shadow-lg flex items-center justify-between transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#C8A45D]/50 hover:bg-[#214C43] ${
          isOpen ? 'ring-2 ring-[#C8A45D]/50 border-[#C8A45D]' : ''
        }`}
      >
        <div className="flex items-center gap-3 text-left overflow-hidden">
          <div className="p-2 rounded-xl bg-[#173B35] text-[#C8A45D] border border-[#C8A45D]/30 shrink-0">
            <Layers3 className="w-4 h-4" />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-serif font-bold text-sm text-[#F8F6F2] truncate">
              {selectedOption.title}
            </span>
            <span className="text-[11px] font-semibold text-[#C8A45D] tracking-wider uppercase">
              {selectedOption.code} ({selectedOption.multiplier} {selectedOption.multiplier === 1 ? 'Level' : 'Levels'})
            </span>
          </div>
        </div>

        <div className="p-1 rounded-full text-[#C8A45D] shrink-0 ml-2">
          <motion.div
            animate={{ rotate: isOpen ? 180 : 0 }}
            transition={{ duration: 0.25 }}
          >
            <ChevronDown className="w-5 h-5" />
          </motion.div>
        </div>
      </button>

      {/* Dropdown Options Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="absolute left-0 right-0 top-full mt-2 z-50 bg-[#4B1120] border border-[#C8A45D] rounded-[20px] shadow-2xl overflow-hidden max-h-80 overflow-y-auto p-2 space-y-1.5 backdrop-blur-md"
          >
            {FLOOR_OPTIONS.map((option) => {
              const isSelected = selectedOption.id === option.id;

              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => {
                    onChange(option);
                    setIsOpen(false);
                  }}
                  className={`w-full p-3 rounded-xl transition-all duration-150 text-left flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'bg-[#C8A45D] text-[#173B35] shadow-md font-bold'
                      : 'bg-transparent text-[#F8F6F2] hover:bg-[#214C43] hover:text-[#F8F6F2]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Custom Circular Radio Selector */}
                    <div
                      className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                        isSelected
                          ? 'border-[#173B35] bg-[#173B35] text-[#C8A45D]'
                          : 'border-[#C8A45D] bg-transparent'
                      }`}
                    >
                      {isSelected && <div className="w-2 h-2 rounded-full bg-[#C8A45D]" />}
                    </div>

                    <div className="flex flex-col min-w-0">
                      <span className={`font-serif font-bold text-sm ${isSelected ? 'text-[#173B35]' : 'text-[#F8F6F2]'}`}>
                        {option.title}
                      </span>
                      <span className={`text-[11px] font-semibold ${isSelected ? 'text-[#4B1120]' : 'text-[#C8A45D]'}`}>
                        {option.code}
                      </span>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="p-1 rounded-full bg-[#173B35] text-[#C8A45D] shrink-0 ml-2">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
