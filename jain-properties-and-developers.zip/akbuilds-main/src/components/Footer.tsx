import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, ArrowRight, ShieldCheck, Instagram, Linkedin, Facebook } from 'lucide-react';
import { BrandLogo } from './BrandLogo';

interface FooterProps {
  onOpenConsultation: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenConsultation }) => {
  return (
    <footer className="bg-[#173B35] text-[#F7F5EF] pt-16 pb-8 border-t border-[#E7B86A]/30 relative overflow-hidden">
      {/* Background blueprint grid overlay */}
      <div className="absolute inset-0 bg-blueprint opacity-40 pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#E7B86A]/20">
          
          {/* Brand & Tagline Col */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/">
              <BrandLogo variant="light" size="lg" />
            </Link>
            <p className="text-stone-300 text-sm font-light leading-relaxed max-w-md pt-2">
              JAIN PROPERTIES AND DEVELOPERS is a premier turnkey Construction, Bespoke Interiors & Professional Project Management firm operating across your region. Driven by structural engineering precision, total package transparency, and single-point accountability.
            </p>
            <div className="pt-2 flex items-center gap-2 text-[#E7B86A] text-xs font-semibold tracking-wider">
              <ShieldCheck className="w-4 h-4" />
              <span>Involved at Every Step • Committed Delivery Timelines</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif font-semibold text-lg text-[#F7F5EF] tracking-wide mb-4 text-[#E7B86A]">
              Quick Links
            </h3>
            <ul className="space-y-2.5 text-sm text-stone-300">
              <li>
                <Link to="/" className="hover:text-[#E7B86A] transition-colors flex items-center gap-1.5">
                  <ArrowRight className="w-3 h-3 text-[#E7B86A]" /> Home
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-[#E7B86A] transition-colors flex items-center gap-1.5">
                  <ArrowRight className="w-3 h-3 text-[#E7B86A]" /> Our Services
                </Link>
              </li>
              <li>
                <Link to="/process" className="hover:text-[#E7B86A] transition-colors flex items-center gap-1.5">
                  <ArrowRight className="w-3 h-3 text-[#E7B86A]" /> Our 12-Stage Process
                </Link>
              </li>
              <li>
                <Link to="/packages" className="hover:text-[#E7B86A] transition-colors flex items-center gap-1.5">
                  <ArrowRight className="w-3 h-3 text-[#E7B86A]" /> Construction Packages
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#E7B86A] transition-colors flex items-center gap-1.5">
                  <ArrowRight className="w-3 h-3 text-[#E7B86A]" /> Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Our Services */}
          <div>
            <h3 className="font-serif font-semibold text-lg text-[#F7F5EF] tracking-wide mb-4 text-[#E7B86A]">
              Our Verticals
            </h3>
            <ul className="space-y-2.5 text-sm text-stone-300">
              <li>
                <Link to="/services#construction" className="hover:text-[#E7B86A] transition-colors">
                  Turnkey Residential Construction
                </Link>
              </li>
              <li>
                <Link to="/services#interiors" className="hover:text-[#E7B86A] transition-colors">
                  Bespoke Modern Interiors
                </Link>
              </li>
              <li>
                <Link to="/services#project-management" className="hover:text-[#E7B86A] transition-colors">
                  Project Management (PMC)
                </Link>
              </li>
              <li>
                <Link to="/packages" className="hover:text-[#E7B86A] transition-colors">
                  Classic / Pure / Premium Specifications
                </Link>
              </li>
              <li>
                <button
                  onClick={onOpenConsultation}
                  className="hover:text-[#E7B86A] text-[#E7B86A] font-medium transition-colors text-left"
                >
                  Request Site Consultation →
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div className="space-y-3">
            <h3 className="font-serif font-semibold text-lg text-[#F7F5EF] tracking-wide mb-4 text-[#E7B86A]">
              Get In Touch
            </h3>
            
            <div className="space-y-2 text-sm text-stone-300">
              <a href="tel:+919810155668" className="flex items-start gap-2.5 hover:text-[#E7B86A] transition-colors">
                <Phone className="w-4 h-4 text-[#E7B86A] shrink-0 mt-1" />
                <div>
                  <div className="font-medium text-[#F7F5EF]">Our Team</div>
                  <div className="text-xs text-stone-400">Property Consultant • +91 90000 00000</div>
                </div>
              </a>

              <a href="tel:+918447219897" className="flex items-start gap-2.5 hover:text-[#E7B86A] transition-colors pt-1">
                <Phone className="w-4 h-4 text-[#E7B86A] shrink-0 mt-1" />
                <div>
                  <div className="font-medium text-[#F7F5EF]">Property Consultant</div>
                  <div className="text-xs text-stone-400">Co-Property Consultant • +91 90000 00000</div>
                </div>
              </a>

              <a href="mailto:contact@jainproperties.com" className="flex items-center gap-2.5 hover:text-[#E7B86A] transition-colors pt-1">
                <Mail className="w-4 h-4 text-[#E7B86A] shrink-0" />
                <span className="text-xs">contact@jainproperties.com</span>
              </a>

              <div className="flex items-start gap-2.5 pt-1 text-xs leading-relaxed text-stone-400">
                <MapPin className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                <span>
                  91 Springboard, 90B Jaipur-Delhi Expy, Udyog Vihar, Sector 18, Gurugram, Sarhol, Haryana 122015.
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* Coverage Cities Badges */}
        <div className="py-6 border-b border-[#E7B86A]/10 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-stone-400">
            <span className="text-[#E7B86A] font-semibold uppercase tracking-wider">Service Footprint:</span>
            <span className="text-[#F7F5EF] font-medium">Delhi</span> | 
            <span className="text-[#F7F5EF] font-medium">your city</span> | 
            <span className="text-[#F7F5EF] font-medium">nearby locations</span> | 
            <span className="text-[#F7F5EF] font-medium">Noida</span>
          </div>

          <div className="flex items-center gap-4 text-stone-400">
            <span className="hover:text-[#E7B86A] cursor-pointer transition-colors">
              <Instagram className="w-4 h-4" />
            </span>
            <span className="hover:text-[#E7B86A] cursor-pointer transition-colors">
              <Linkedin className="w-4 h-4" />
            </span>
            <span className="hover:text-[#E7B86A] cursor-pointer transition-colors">
              <Facebook className="w-4 h-4" />
            </span>
          </div>
        </div>

        {/* Copyright & Disclaimer */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between text-xs text-stone-400 gap-3">
          <div>
            © {new Date().getFullYear()} JAIN PROPERTIES AND DEVELOPERS. All Rights Reserved.
          </div>
          <div className="text-stone-500 hidden sm:block">
            Construction • Bespoke Interiors • Project Management Consultancy
          </div>
          <div className="flex items-center gap-1 text-stone-400">
            <span>Powered by</span>
            <a
              href="https://devsiy.in"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#E7B86A] font-semibold hover:text-white hover:underline transition-colors tracking-wide"
            >
              Devsiy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

