import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Building2, Sparkles, ClipboardCheck, ArrowRight, ShieldCheck, 
  CheckCircle2, XCircle, Star, Quote, Award, Check
} from 'lucide-react';
import { testimonials } from '../data/testimonialsData';

interface HomeProps {
  onOpenConsultation: () => void;
}

export const Home: React.FC<HomeProps> = ({ onOpenConsultation }) => {
  return (
    <div className="space-y-0">
      {/* 1. LUXURY CONSTRUCTION HERO */}
      <section className="relative bg-[#173B35] text-[#F7F5EF] min-h-[90vh] flex items-center justify-center overflow-hidden py-20 px-4 sm:px-6 lg:px-8 border-b border-[#E7B86A]/30">
        {/* Background Image with Dark Burgundy Overlay */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-25 transform scale-105 transition-transform duration-1000"
          style={{ 
            backgroundImage: `url('/images/hero-bg.jpg')` 
          }}
        />
        {/* Blueprint Grid & Vignette Overlay */}
        <div className="absolute inset-0 bg-blueprint opacity-60 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#173B35] via-[#173B35]/80 to-transparent" />

        <div className="relative max-w-5xl mx-auto text-center space-y-8 z-10">
          {/* Top Brand Pill */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#214C43]/80 border border-[#E7B86A]/40 text-[#E7B86A] text-xs uppercase tracking-widest font-semibold backdrop-blur-sm shadow-md"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Turnkey Construction & Interior Solutions</span>
          </motion.div>

          {/* Title & Tagline */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="space-y-3"
          >
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-cinzel font-bold text-[#F7F5EF] tracking-wider leading-tight">
              JAIN PROPERTIES AND DEVELOPERS
            </h1>
            <div className="text-2xl sm:text-3xl lg:text-4xl font-serif text-[#E7B86A] font-medium tracking-wide italic">
              “Involved at Every Step”
            </div>
            <p className="text-stone-300 text-sm sm:text-base lg:text-lg max-w-2xl mx-auto font-light tracking-wide pt-2">
              Construction <span className="text-[#E7B86A]">•</span> Interiors <span className="text-[#E7B86A]">•</span> Project Management
            </p>
          </motion.div>

          {/* Hero Short Copy */}
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-stone-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed font-light"
          >
            Building luxury villas, builder floors, and high-end residential interiors across your city, Delhi, Noida & nearby locations with complete cost transparency and on-time project delivery.
          </motion.p>

          {/* Action CTAs */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4"
          >
            <button
              onClick={onOpenConsultation}
              className="w-full sm:w-auto px-8 py-4 rounded-lg bg-[#E7B86A] hover:bg-[#D5A854] text-[#173B35] font-bold text-xs uppercase tracking-widest shadow-xl hover:shadow-2xl transition-all duration-300 flex items-center justify-center gap-3 border border-[#F7F5EF]/30 cursor-pointer group"
            >
              <span>Start Your Project</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <Link
              to="/services"
              className="w-full sm:w-auto px-8 py-4 rounded-lg bg-[#214C43]/90 hover:bg-[#214C43] text-[#F7F5EF] font-semibold text-xs uppercase tracking-widest border border-[#E7B86A]/40 transition-all duration-300 flex items-center justify-center gap-2 backdrop-blur-sm"
            >
              <span>Explore Services</span>
            </Link>
          </motion.div>

          {/* Key Guarantee Badges */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="pt-8 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto text-left text-xs text-stone-300 border-t border-[#E7B86A]/20"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0" />
              <span>Strict budget control across projects.</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0" />
              <span>Over 120 quality checkpoints</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0" />
              <span>On-time project delivery</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0" />
              <span>A single point of contact.</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 2. COMPANY ABOUT SECTION */}
      <section className="py-16 md:py-24 bg-[#F7F5EF] border-b border-[#E7DFD5] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Visual Column with Architectural Framing */}
            <div className="lg:col-span-6 relative">
              <div className="relative rounded-xl overflow-hidden shadow-2xl border border-[#E7B86A]/30 bg-[#173B35]">
                <img 
                  src="/images/about-interior.jpg" 
                  alt="Jain Properties and Developers Luxury Interior Project"
                  className="w-full h-[420px] object-cover"
                  loading="lazy"
                  onError={(e) => {
                    // Safety fallback if image ever fails
                    e.currentTarget.style.display = 'none';
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#173B35]/80 via-transparent to-transparent pointer-events-none" />
                <div className="absolute bottom-6 left-6 right-6 text-[#F7F5EF] p-4 bg-[#173B35]/90 backdrop-blur-md rounded-lg border border-[#E7B86A]/40">
                  <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-wider mb-1">
                    Design & Construction Integrity
                  </div>
                  <div className="font-serif text-lg font-bold">
                    Turnkey Architectural Precision Across your region
                  </div>
                </div>
              </div>
              {/* Decorative Background Frame */}
              <div className="absolute -bottom-4 -right-4 w-full h-full border-2 border-[#E7B86A]/30 rounded-xl -z-10 hidden sm:block" />
            </div>

            {/* Text Copy Column */}
            <div className="lg:col-span-6 space-y-6">
              <div className="inline-flex items-center gap-2 text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
                <span className="w-8 h-0.5 bg-[#E7B86A]" />
                <span>About Jain Properties and Developers</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#214C43] leading-tight">
                We Build Beautiful Spaces with Quality and Trust
              </h2>

              <p className="text-stone-700 text-sm sm:text-base leading-relaxed font-light">
                At Jain Properties and Developers, we bridge the gap between architectural vision and flawless execution.
              </p>

              <p className="text-stone-700 text-sm sm:text-base leading-relaxed font-light">
                Built around trust and transparency, we deliver turnkey design-build and project management solutions that eliminate stress, cost escalations, and poor workmanship.
              </p>

              <p className="text-stone-700 text-sm sm:text-base leading-relaxed font-light">
                From soil testing to key handover.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-lg bg-white border border-[#E7DFD5] shadow-xs">
                  <div className="text-2xl font-serif font-bold text-[#214C43]">Verified</div>
                  <div className="text-xs text-stone-600 font-medium">Material Brand Compliance</div>
                </div>
                <div className="p-4 rounded-lg bg-white border border-[#E7DFD5] shadow-xs">
                  <div className="text-2xl font-serif font-bold text-[#214C43]">Strict</div>
                  <div className="text-xs text-stone-600 font-medium">Budget Control Across Projects</div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={onOpenConsultation}
                  className="px-6 py-3 bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] font-semibold text-xs uppercase tracking-wider rounded-lg shadow-md transition-all border border-[#E7B86A]/40 cursor-pointer"
                >
                  Schedule A Site Walkthrough
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. TEAM SECTION */}
      <section className="py-16 md:py-20 bg-[#F4EFEA] border-b border-[#E7DFD5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center space-y-2 max-w-xl mx-auto">
            <div className="text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
              Leadership & Vision
            </div>
            <h2 className="text-3xl font-serif font-bold text-[#214C43]">
              Our Founding Team
            </h2>
            <p className="text-stone-600 text-sm font-light">
              Direct founder involvement across every construction phase in your region.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Our Team Card */}
            <div className="bg-[#F7F5EF] rounded-2xl border border-[#E7DFD5] p-8 shadow-luxury flex flex-col items-center text-center space-y-4 relative overflow-hidden group hover:border-[#E7B86A] transition-all">
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full overflow-hidden border-4 border-[#E7B86A] shadow-lg group-hover:scale-105 transition-transform duration-300">
                <img
                  src="/images/construction.jpg"
                  alt="Our Team - Property Team Jain Properties and Developers"
                  className="w-full h-full object-cover object-top"
                  loading="eager"
                />
              </div>
              <div className="space-y-1">
                <h3 className="text-2xl font-serif font-bold text-[#214C43]">
                  Our Team
                </h3>
                <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-widest">
                  Property Team
                </div>
              </div>
              <p className="text-stone-600 text-xs font-light leading-relaxed max-w-xs">
                Spearheading turnkey design-build strategy, structural engineering standards, and client relationships across your region.
              </p>
              <a
                href="tel:+919810155668"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#214C43]/5 hover:bg-[#214C43] text-[#214C43] hover:text-[#F7F5EF] font-semibold text-xs transition-colors border border-[#214C43]/15"
              >
                <span>+91 90000 00000</span>
              </a>
            </div>

            {/* Property Consultant Card */}
            <div className="bg-[#F7F5EF] rounded-2xl border border-[#E7DFD5] p-8 shadow-luxury flex flex-col items-center text-center space-y-4 relative overflow-hidden group hover:border-[#E7B86A] transition-all">
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full overflow-hidden border-4 border-[#E7B86A] shadow-lg group-hover:scale-105 transition-transform duration-300">
                <img
                  src="/images/about-interior.jpg"
                  alt="Property Consultant - Property Team Jain Properties and Developers"
                  className="w-full h-full object-cover object-top"
                  loading="eager"
                />
              </div>
              <div className="space-y-1">
                <h3 className="text-2xl font-serif font-bold text-[#214C43]">
                  Property Consultant
                </h3>
                <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-widest">
                  Property Team
                </div>
              </div>
              <p className="text-stone-600 text-xs font-light leading-relaxed max-w-xs">
                Directing site operations, contractor onboarding, material ratio audits, and guaranteed milestone handovers.
              </p>
              <a
                href="tel:+918447219897"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#214C43]/5 hover:bg-[#214C43] text-[#214C43] hover:text-[#F7F5EF] font-semibold text-xs transition-colors border border-[#214C43]/15"
              >
                <span>+91 90000 00000</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 4. SERVICES PREVIEW CARDS WITH GUARANTEED LOCAL IMAGES */}
      <section className="py-16 md:py-24 bg-[#F7F5EF] border-b border-[#E7DFD5] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
              <span className="w-6 h-0.5 bg-[#E7B86A]" />
              <span>Core Expertise</span>
              <span className="w-6 h-0.5 bg-[#E7B86A]" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#214C43]">
              Our Verticals
            </h2>
            <p className="text-stone-600 text-sm font-light leading-relaxed">
              Comprehensive end-to-end solutions tailored for high-end residential and commercial builds.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Service 1: Construction */}
            <motion.div 
              whileHover={{ y: -6 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-xl overflow-hidden border border-[#E7DFD5] shadow-luxury shadow-luxury-hover flex flex-col justify-between"
            >
              <div>
                <div className="relative h-56 bg-[#173B35] overflow-hidden">
                  <img 
                    src="/images/construction.jpg" 
                    alt="Turnkey Construction Jain Properties and Developers"
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="eager"
                  />
                  <div className="absolute top-4 left-4 p-2.5 bg-[#214C43] text-[#E7B86A] rounded-lg shadow-md border border-[#E7B86A]/40 z-10">
                    <Building2 className="w-6 h-6" />
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <h3 className="text-xl font-serif font-bold text-[#214C43]">
                    Turnkey Construction
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm font-light leading-relaxed">
                    Complete civil and structural execution from foundation excavation to final plaster. Built with Fe 500D grade steel, high-grade cement, and multi-layer waterproofing.
                  </p>
                  
                  <ul className="space-y-2 text-xs text-stone-700 pt-2 border-t border-stone-200">
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Geotechnical Soil Testing & RCC Frame
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Brand Certified Material Supply
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Committed Milestone Timelines
                    </li>
                  </ul>
                </div>
              </div>

              <div className="p-6 pt-0">
                <Link
                  to="/services#construction"
                  className="w-full py-2.5 px-4 bg-[#214C43]/5 hover:bg-[#214C43] text-[#214C43] hover:text-[#F7F5EF] font-semibold text-xs uppercase tracking-wider rounded-lg transition-all duration-200 border border-[#214C43]/20 flex items-center justify-center gap-2"
                >
                  <span>Construction Details</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#E7B86A]" />
                </Link>
              </div>
            </motion.div>

            {/* Service 2: Interiors */}
            <motion.div 
              whileHover={{ y: -6 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-xl overflow-hidden border border-[#E7DFD5] shadow-luxury shadow-luxury-hover flex flex-col justify-between"
            >
              <div>
                <div className="relative h-56 bg-[#173B35] overflow-hidden">
                  <img 
                    src="/images/interiors.jpg" 
                    alt="Bespoke Interiors Jain Properties and Developers"
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="eager"
                  />
                  <div className="absolute top-4 left-4 p-2.5 bg-[#214C43] text-[#E7B86A] rounded-lg shadow-md border border-[#E7B86A]/40 z-10">
                    <Sparkles className="w-6 h-6" />
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <h3 className="text-xl font-serif font-bold text-[#214C43]">
                    Bespoke Interiors
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm font-light leading-relaxed">
                    Luxury space planning, bespoke modular kitchens with Hettich hardware, veneer wall treatments, false ceilings, and Italian marble flooring.
                  </p>

                  <ul className="space-y-2 text-xs text-stone-700 pt-2 border-t border-stone-200">
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> HDMR Termite-Proof Joinery
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> 3D Renders Prior to Ground Execution
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Italian Marble & Ambient Cove Lighting
                    </li>
                  </ul>
                </div>
              </div>

              <div className="p-6 pt-0">
                <Link
                  to="/services#interiors"
                  className="w-full py-2.5 px-4 bg-[#214C43]/5 hover:bg-[#214C43] text-[#214C43] hover:text-[#F7F5EF] font-semibold text-xs uppercase tracking-wider rounded-lg transition-all duration-200 border border-[#214C43]/20 flex items-center justify-center gap-2"
                >
                  <span>Interior Gallery & Specs</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#E7B86A]" />
                </Link>
              </div>
            </motion.div>

            {/* Service 3: Project Management */}
            <motion.div 
              whileHover={{ y: -6 }}
              transition={{ duration: 0.2 }}
              className="bg-white rounded-xl overflow-hidden border border-[#E7DFD5] shadow-luxury shadow-luxury-hover flex flex-col justify-between"
            >
              <div>
                <div className="relative h-56 bg-[#173B35] overflow-hidden">
                  <img 
                    src="/images/pmc.jpg" 
                    alt="Project Management (PMC) Jain Properties and Developers"
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    loading="eager"
                  />
                  <div className="absolute top-4 left-4 p-2.5 bg-[#214C43] text-[#E7B86A] rounded-lg shadow-md border border-[#E7B86A]/40 z-10">
                    <ClipboardCheck className="w-6 h-6" />
                  </div>
                </div>

                <div className="p-6 space-y-3">
                  <h3 className="text-xl font-serif font-bold text-[#214C43]">
                    Project Management (PMC)
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm font-light leading-relaxed">
                    Third-party technical site audits, material ratio checks, contractor supervision, budget optimization, and snag list walkthroughs.
                  </p>

                  <ul className="space-y-2 text-xs text-stone-700 pt-2 border-t border-stone-200">
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Over 120 Quality Checkpoints
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Cost Verification & Bill Auditing
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#E7B86A]" /> Live Weekly Progress Photo Updates
                    </li>
                  </ul>
                </div>
              </div>

              <div className="p-6 pt-0">
                <Link
                  to="/services#project-management"
                  className="w-full py-2.5 px-4 bg-[#214C43]/5 hover:bg-[#214C43] text-[#214C43] hover:text-[#F7F5EF] font-semibold text-xs uppercase tracking-wider rounded-lg transition-all duration-200 border border-[#214C43]/20 flex items-center justify-center gap-2"
                >
                  <span>PMC Consultancy</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#E7B86A]" />
                </Link>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* 5. PROJECT STATS */}
      <section className="py-16 bg-[#173B35] text-[#F7F5EF] border-b border-[#E7B86A]/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-blueprint opacity-50 pointer-events-none" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-2 max-w-xl mx-auto mb-12">
            <div className="text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
              Proven Track Record Across your region
            </div>
            <h2 className="text-3xl font-serif font-bold text-[#F7F5EF]">
              Execution Milestones
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center max-w-4xl mx-auto">
            
            <div className="p-6 rounded-xl bg-[#3B0F1A]/80 border border-[#E7B86A]/30 backdrop-blur-sm space-y-2">
              <div className="text-4xl sm:text-5xl font-cinzel font-bold text-[#E7B86A]">
                10
              </div>
              <div className="text-base font-serif font-bold text-[#F7F5EF]">
                Projects Executed
              </div>
              <p className="text-xs text-stone-400 font-light">
                Turnkey villas & luxury floors built across NCR.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#3B0F1A]/80 border border-[#E7B86A]/30 backdrop-blur-sm space-y-2">
              <div className="text-4xl sm:text-5xl font-cinzel font-bold text-[#E7B86A]">
                5
              </div>
              <div className="text-base font-serif font-bold text-[#F7F5EF]">
                Projects Delivered
              </div>
              <p className="text-xs text-stone-400 font-light">
                Delivered with high client satisfaction.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#3B0F1A]/80 border border-[#E7B86A]/30 backdrop-blur-sm space-y-2">
              <div className="text-4xl sm:text-5xl font-cinzel font-bold text-[#E7B86A]">
                5
              </div>
              <div className="text-base font-serif font-bold text-[#F7F5EF]">
                Projects In Process
              </div>
              <p className="text-xs text-stone-400 font-light">
                Active high-end construction sites under daily project supervision.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* 6. "WHY JAIN PROPERTIES AND DEVELOPERS?" COMPARISON */}
      <section className="py-16 md:py-24 bg-[#F7F5EF] border-b border-[#E7DFD5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
              <span className="w-6 h-0.5 bg-[#E7B86A]" />
              <span>Standard vs Professional Standard</span>
              <span className="w-6 h-0.5 bg-[#E7B86A]" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#214C43]">
              Why Choose Jain Properties and Developers?
            </h2>
            <p className="text-stone-600 text-sm font-light leading-relaxed">
              Compare how our engineering-driven approach protects your investment compared to standard local contractors.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[640px]">
              <thead>
                <tr className="border-b-2 border-[#214C43]">
                  <th className="py-4 px-6 bg-[#EFE8DE] text-[#214C43] font-serif font-bold text-base w-1/4">
                    Comparison Parameter
                  </th>
                  <th className="py-4 px-6 bg-stone-200 text-stone-700 font-serif font-bold text-base w-3/8">
                    Standard Local Contractors
                  </th>
                  <th className="py-4 px-6 bg-[#214C43] text-[#F7F5EF] font-serif font-bold text-base w-3/8 border-l border-[#E7B86A]/40">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-[#E7B86A]" />
                      <span>JAIN PROPERTIES AND DEVELOPERS</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200 text-sm">
                
                {/* Row 1 */}
                <tr>
                  <td className="py-4 px-6 font-bold text-[#214C43] bg-[#F7F5EF]">
                    Cost & Budget Transparency
                  </td>
                  <td className="py-4 px-6 text-stone-600 bg-stone-50">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                      <span>Hidden charges, sudden mid-project price escalations, and unwritten extra costs.</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-[#F7F5EF] bg-[#3B0F1A] border-l border-[#E7B86A]/30">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                      <span className="font-medium">Strict budget control across projects with zero cost escalations.</span>
                    </div>
                  </td>
                </tr>

                {/* Row 2 */}
                <tr>
                  <td className="py-4 px-6 font-bold text-[#214C43] bg-[#F7F5EF]">
                    Quality & Engineering Audits
                  </td>
                  <td className="py-4 px-6 text-stone-600 bg-stone-50">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                      <span>Unskilled labor, unmonitored concrete mix ratios, no cube testing or soil analysis.</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-[#F7F5EF] bg-[#3B0F1A] border-l border-[#E7B86A]/30">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                      <span className="font-medium">Soil testing, over 120 quality checkpoints, and cube strength reports.</span>
                    </div>
                  </td>
                </tr>

                {/* Row 3 */}
                <tr>
                  <td className="py-4 px-6 font-bold text-[#214C43] bg-[#F7F5EF]">
                    Timelines & Deadlines
                  </td>
                  <td className="py-4 px-6 text-stone-600 bg-stone-50">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                      <span>Delays running into months without financial accountability or penalization.</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-[#F7F5EF] bg-[#3B0F1A] border-l border-[#E7B86A]/30">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                      <span className="font-medium">On-time project delivery bound by milestone tracking.</span>
                    </div>
                  </td>
                </tr>

                {/* Row 4 */}
                <tr>
                  <td className="py-4 px-6 font-bold text-[#214C43] bg-[#F7F5EF]">
                    Client Involvement & Stress
                  </td>
                  <td className="py-4 px-6 text-stone-600 bg-stone-50">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                      <span>Client forced to coordinate between 10+ sub-contractors, mason, electrician, and material suppliers.</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-[#F7F5EF] bg-[#3B0F1A] border-l border-[#E7B86A]/30">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                      <span className="font-medium">A single point of contact. "Involved at Every Step" while you relax.</span>
                    </div>
                  </td>
                </tr>

                {/* Row 5 */}
                <tr>
                  <td className="py-4 px-6 font-bold text-[#214C43] bg-[#F7F5EF]">
                    Material Brand Sourcing
                  </td>
                  <td className="py-4 px-6 text-stone-600 bg-stone-50">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                      <span>Unverified local sourcing, sub-grade rebar steel, and uncertified duplicate brands.</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-[#F7F5EF] bg-[#3B0F1A] border-l border-[#E7B86A]/30">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                      <span className="font-medium">Direct factory sourcing from brands such as Tata Tiscon, UltraTech, Kohler, Fenesta, and Asian Paints.</span>
                    </div>
                  </td>
                </tr>

                {/* Row 6 */}
                <tr>
                  <td className="py-4 px-6 font-bold text-[#214C43] bg-[#F7F5EF]">
                    Post-Handover Support
                  </td>
                  <td className="py-4 px-6 text-stone-600 bg-stone-50">
                    <div className="flex items-start gap-2">
                      <XCircle className="w-4 h-4 text-red-700 shrink-0 mt-0.5" />
                      <span>Contractors vanish post payment. Zero warranty or rectification for leakages/cracks.</span>
                    </div>
                  </td>
                  <td className="py-4 px-6 text-[#F7F5EF] bg-[#3B0F1A] border-l border-[#E7B86A]/30">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0 mt-0.5" />
                      <span className="font-medium">10-Year waterproofing warranty & dedicated post-handover maintenance team.</span>
                    </div>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 7. TESTIMONIALS */}
      <section className="py-16 md:py-24 bg-[#F4EFEA] border-b border-[#E7DFD5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <div className="inline-flex items-center gap-2 text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
              <span className="w-6 h-0.5 bg-[#E7B86A]" />
              <span>Client Endorsements</span>
              <span className="w-6 h-0.5 bg-[#E7B86A]" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#214C43]">
              What Our Clients Say
            </h2>
            <p className="text-stone-600 text-sm font-light">
              High Client Satisfaction across homeowners and investors who built with Jain Properties and Developers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((item) => (
              <motion.div
                key={item.id}
                whileHover={{ y: -4 }}
                className="bg-[#F7F5EF] p-8 rounded-xl border border-[#E7DFD5] shadow-luxury flex flex-col justify-between relative space-y-6"
              >
                <Quote className="absolute top-6 right-6 w-10 h-10 text-[#E7B86A]/20" />

                <div className="space-y-4">
                  {/* Rating Stars */}
                  <div className="flex items-center gap-1 text-[#E7B86A]">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>

                  <p className="text-stone-700 text-sm sm:text-base font-light italic leading-relaxed">
                    “{item.quote}”
                  </p>
                </div>

                {/* Client Avatar & Meta */}
                <div className="flex items-center gap-4 pt-4 border-t border-stone-200">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-[#E7B86A]"
                    loading="lazy"
                  />
                  <div>
                    <h3 className="font-serif font-bold text-[#214C43] text-base">
                      {item.name}
                    </h3>
                    <div className="text-xs font-medium text-[#E7B86A]">
                      {item.roleOrLocation}
                    </div>
                    <div className="text-[11px] text-stone-500 font-light">
                      {item.projectType}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </section>

      {/* 8. FINAL CONSULTATION CTA BANNER */}
      <section className="py-16 md:py-20 bg-[#173B35] text-[#F7F5EF] relative overflow-hidden border-b border-[#E7B86A]/30">
        <div className="absolute inset-0 bg-blueprint opacity-60 pointer-events-none" />

        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#214C43] border border-[#E7B86A]/40 text-[#E7B86A] text-xs font-semibold uppercase tracking-widest">
            <Award className="w-3.5 h-3.5" />
            <span>Turnkey Build Desk</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-cinzel font-bold tracking-wide text-[#F7F5EF]">
            Ready to Build Your Space with Complete Peace of Mind?
          </h2>

          <p className="text-stone-300 text-sm sm:text-base max-w-xl mx-auto font-light leading-relaxed">
            Contact Jain Properties and Developers today for a complimentary plot site visit, material estimation, and 2D layout consultation.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onOpenConsultation}
              className="w-full sm:w-auto px-8 py-4 rounded-lg bg-[#E7B86A] hover:bg-[#D5A854] text-[#173B35] font-bold text-xs uppercase tracking-widest shadow-xl transition-all border border-[#F7F5EF]/30 flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Request Free Consultation</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href="tel:+919810155668"
              className="w-full sm:w-auto px-8 py-4 rounded-lg bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] font-semibold text-xs uppercase tracking-widest border border-[#E7B86A]/40 transition-all flex items-center justify-center gap-2"
            >
              <span>Call +91 90000 00000</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
