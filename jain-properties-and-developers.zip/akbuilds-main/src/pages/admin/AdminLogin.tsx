import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, Eye, EyeOff, ShieldCheck, AlertCircle } from 'lucide-react';

const ADMIN_KEY = 'akbuilds_admin_session';

export const AdminLogin: React.FC = () => {
  const [password, setPassword] = useState('');
  const [showPw, setShowPw]     = useState(false);
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const navigate = useNavigate();

  // If already logged in, redirect
  useEffect(() => {
    if (sessionStorage.getItem(ADMIN_KEY) === 'true') {
      navigate('/admin/dashboard', { replace: true });
    }
  }, [navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const correctPw = import.meta.env.VITE_ADMIN_PASSWORD || 'akbuilds@admin2024';

    setTimeout(() => {
      if (password === correctPw) {
        sessionStorage.setItem(ADMIN_KEY, 'true');
        navigate('/admin/dashboard', { replace: true });
      } else {
        setError('Incorrect password. Please try again.');
        setLoading(false);
      }
    }, 400);
  };

  return (
    <div className="min-h-screen bg-[#F7F5EF] flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl border border-stone-200 overflow-hidden">
          {/* Header */}
          <div className="bg-[#214C43] p-8 text-center">
            <div className="w-16 h-16 bg-[#E7B86A]/20 rounded-full flex items-center justify-center mx-auto mb-4 border border-[#E7B86A]/40">
              <ShieldCheck className="w-8 h-8 text-[#E7B86A]" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white">Jain Properties and Developers</h1>
            <p className="text-[#E7B86A] text-sm mt-1 font-medium tracking-wide">CRM Admin Panel</p>
          </div>

          {/* Form */}
          <div className="p-8">
            <h2 className="text-lg font-semibold text-stone-800 mb-6 text-center">Sign In to Continue</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
                  Admin Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <Lock className="w-4 h-4 text-stone-400" />
                  </div>
                  <input
                    type={showPw ? 'text' : 'password'}
                    value={password}
                    onChange={e => { setPassword(e.target.value); setError(''); }}
                    placeholder="Enter admin password"
                    className="w-full pl-10 pr-10 py-3 border border-stone-300 rounded-lg text-sm focus:outline-none focus:border-[#214C43] focus:ring-1 focus:ring-[#214C43] transition-all"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(!showPw)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-stone-400 hover:text-stone-600"
                  >
                    {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-4 py-2.5">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading || !password}
                className="w-full py-3 bg-[#214C43] hover:bg-[#3B0F1A] disabled:opacity-60 text-white font-semibold rounded-lg transition-all duration-200 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span className="animate-pulse">Verifying…</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    Access CRM Dashboard
                  </>
                )}
              </button>
            </form>

            <p className="text-center text-xs text-stone-400 mt-6">
              Jain Properties and Developers · Internal Admin Panel · Unauthorised access is prohibited.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

