import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, TrendingUp, Calendar, CheckCircle2, Phone, MapPin, Package2,
  Search, Filter, Download, RefreshCw, LogOut, MessageSquare,
  ChevronDown, Building2, Clock, XCircle, FileSpreadsheet,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import {
  fetchAllLeads, fetchLeadStats, updateLeadStatus,
  Lead, LeadStats, LeadStatus, STATUS_LABELS, STATUS_COLORS,
} from '../../lib/adminSupabase';

const ADMIN_KEY = 'akbuilds_admin_session';

// ─── Stat Card ────────────────────────────────────────────────────────────────

const StatCard: React.FC<{
  label: string; value: number | string; icon: React.ReactNode; color: string;
}> = ({ label, value, icon, color }) => (
  <div className={`bg-white rounded-xl border ${color} p-5 flex items-center gap-4 shadow-sm`}>
    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${color.replace('border-', 'bg-').replace('-200', '-50')}`}>
      {icon}
    </div>
    <div>
      <p className="text-2xl font-bold text-stone-900">{value}</p>
      <p className="text-xs text-stone-500 font-medium uppercase tracking-wide">{label}</p>
    </div>
  </div>
);

// ─── Status Badge ─────────────────────────────────────────────────────────────

const StatusBadge: React.FC<{ status: LeadStatus }> = ({ status }) => (
  <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${STATUS_COLORS[status]}`}>
    {STATUS_LABELS[status]}
  </span>
);

// ─── Status Dropdown ──────────────────────────────────────────────────────────

const StatusDropdown: React.FC<{
  leadId: string; current: LeadStatus; onChange: (id: string, s: LeadStatus) => void;
}> = ({ leadId, current, onChange }) => {
  const statuses: LeadStatus[] = ['new', 'called', 'site_visit_scheduled', 'converted', 'not_interested'];
  return (
    <select
      value={current}
      onChange={e => onChange(leadId, e.target.value as LeadStatus)}
      className="text-xs border border-stone-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-[#214C43] bg-white cursor-pointer"
    >
      {statuses.map(s => (
        <option key={s} value={s}>{STATUS_LABELS[s]}</option>
      ))}
    </select>
  );
};

// ─── Main Dashboard ───────────────────────────────────────────────────────────

export const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [leads, setLeads]       = useState<Lead[]>([]);
  const [stats, setStats]       = useState<LeadStats | null>(null);
  const [loading, setLoading]   = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError]       = useState('');
  const [search, setSearch]     = useState('');
  const [filterStatus, setFilterStatus] = useState<LeadStatus | 'all'>('all');
  const [filterPkg, setFilterPkg] = useState('all');

  // Auth guard
  useEffect(() => {
    if (sessionStorage.getItem(ADMIN_KEY) !== 'true') {
      navigate('/admin', { replace: true });
    }
  }, [navigate]);

  const loadData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    setError('');
    try {
      const [leadsData, statsData] = await Promise.all([fetchAllLeads(), fetchLeadStats()]);
      setLeads(leadsData);
      setStats(statsData);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleStatusChange = async (id: string, status: LeadStatus) => {
    // Optimistic update
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
    try {
      await updateLeadStatus(id, status);
    } catch {
      // Revert on failure
      loadData(true);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem(ADMIN_KEY);
    navigate('/admin', { replace: true });
  };

  // Helper to clean any corrupted mangled text (mojibake) from legacy entries
  const cleanText = (text: string | null | undefined): string => {
    if (!text) return '';
    return text
      .replace(/â€¢/g, '•')
      .replace(/â€“/g, '-')
      .replace(/â€”/g, '-')
      .replace(/â‚¹/g, 'Rs. ')
      .replace(/â€¦/g, '...')
      .replace(/Â·/g, '·')
      .replace(/ï¸/g, '')
      .replace(/âƒ£/g, '');
  };

  // ─── Excel Export (.xlsx) ─────────────────────────────────────────────────────

  const exportExcel = () => {
    const data = filteredLeads.map(l => ({
      'Date': new Date(l.created_at).toLocaleString('en-IN'),
      'Name': cleanText(l.name),
      'Phone': cleanText(l.phone),
      'Plot Location': cleanText(l.plot_location),
      'Plot Size': cleanText(l.plot_size),
      'Package Interest': cleanText(l.package_interest),
      'Status': STATUS_LABELS[l.status] || l.status,
      'Source': cleanText(l.source),
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    worksheet['!cols'] = [
      { wch: 22 }, // Date
      { wch: 20 }, // Name
      { wch: 16 }, // Phone
      { wch: 30 }, // Location
      { wch: 16 }, // Size
      { wch: 36 }, // Package
      { wch: 18 }, // Status
      { wch: 16 }, // Source
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Jain Properties and Developers Leads');
    XLSX.writeFile(workbook, `akbuilds-leads-${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // ─── CSV Export ──────────────────────────────────────────────────────────────

  const exportCSV = () => {
    const headers = ['Date', 'Name', 'Phone', 'Plot Location', 'Plot Size', 'Package', 'Status', 'Source'];
    const rows = filteredLeads.map(l => [
      new Date(l.created_at).toLocaleString('en-IN'),
      cleanText(l.name),
      cleanText(l.phone),
      cleanText(l.plot_location),
      cleanText(l.plot_size),
      cleanText(l.package_interest),
      STATUS_LABELS[l.status],
      cleanText(l.source),
    ]);
    const csvContent = [headers, ...rows].map(r => r.map(c => `"${(c || '').replace(/"/g, '""')}"`).join(',')).join('\n');
    // Prepend UTF-8 BOM (\uFEFF) so Excel opens it with UTF-8 encoding cleanly
    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `akbuilds-leads-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };



  // ─── Filtering ───────────────────────────────────────────────────────────────

  const filteredLeads = leads.filter(l => {
    const q = search.toLowerCase();
    const matchesSearch =
      !q ||
      l.name.toLowerCase().includes(q) ||
      l.phone.includes(q) ||
      l.plot_location.toLowerCase().includes(q) ||
      l.package_interest.toLowerCase().includes(q);
    const matchesStatus = filterStatus === 'all' || l.status === filterStatus;
    const matchesPkg =
      filterPkg === 'all' ||
      l.package_interest.toLowerCase().includes(filterPkg.toLowerCase());
    return matchesSearch && matchesStatus && matchesPkg;
  });

  // ─── WhatsApp URL ─────────────────────────────────────────────────────────────

  const waUrl = (lead: Lead) => {
    const name = cleanText(lead.name);
    const loc = cleanText(lead.plot_location);
    const msg = `Hi ${name}, I'm from Jain Properties and Developers. Following up on your consultation request for ${loc}. When would be a good time to connect?`;
    return `https://wa.me/91${lead.phone}?text=${encodeURIComponent(msg)}`;
  };


  // ─── Render ───────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-[#214C43] border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-stone-600 font-medium">Loading CRM…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 font-sans">
      {/* Top Nav */}
      <header className="bg-[#214C43] text-white px-6 py-4 flex items-center justify-between shadow-lg sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <Building2 className="w-6 h-6 text-[#E7B86A]" />
          <div>
            <h1 className="font-serif font-bold text-lg leading-none">Jain Properties and Developers</h1>
            <p className="text-[#E7B86A] text-xs font-medium">CRM Dashboard</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="flex items-center gap-1.5 text-xs text-white/70 hover:text-white transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 text-xs bg-white/10 hover:bg-white/20 px-3 py-1.5 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
            <XCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* Stats Grid */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            <StatCard label="Total Leads"    value={stats.total_leads}         icon={<Users className="w-6 h-6 text-blue-600" />}    color="border-blue-200" />
            <StatCard label="Today"          value={stats.today_leads}         icon={<Calendar className="w-6 h-6 text-green-600" />} color="border-green-200" />
            <StatCard label="New"            value={stats.new_leads}           icon={<Clock className="w-6 h-6 text-amber-600" />}   color="border-amber-200" />
            <StatCard label="Site Visits"    value={stats.site_visit_leads}    icon={<MapPin className="w-6 h-6 text-purple-600" />}  color="border-purple-200" />
            <StatCard label="Converted"      value={stats.converted_leads}     icon={<CheckCircle2 className="w-6 h-6 text-emerald-600" />} color="border-emerald-200" />
            <StatCard label="Not Interested" value={stats.not_interested_leads} icon={<XCircle className="w-6 h-6 text-red-500" />}  color="border-red-200" />
          </div>
        )}

        {/* Package Breakdown */}
        {stats && (
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: 'Classic', value: stats.classic_leads, color: 'border-stone-300 bg-stone-50' },
              { label: 'Pure',    value: stats.pure_leads,    color: 'border-amber-300 bg-amber-50' },
              { label: 'Premium', value: stats.premium_leads, color: 'border-red-900/30 bg-red-50' },
            ].map(p => (
              <div key={p.label} className={`rounded-xl border ${p.color} p-4 text-center`}>
                <Package2 className="w-5 h-5 mx-auto mb-1 text-stone-500" />
                <p className="text-xl font-bold text-stone-900">{p.value}</p>
                <p className="text-xs text-stone-500 font-medium">{p.label} Package</p>
              </div>
            ))}
          </div>
        )}

        {/* Filters + Actions */}
        <div className="bg-white rounded-xl border border-stone-200 p-4 shadow-sm">
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
            <div className="flex flex-col sm:flex-row gap-3 flex-1">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by name, phone, location…"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-sm border border-stone-200 rounded-lg focus:outline-none focus:border-[#214C43]"
                />
              </div>

              {/* Status Filter */}
              <div className="relative">
                <Filter className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  value={filterStatus}
                  onChange={e => setFilterStatus(e.target.value as LeadStatus | 'all')}
                  className="pl-9 pr-8 py-2 text-sm border border-stone-200 rounded-lg focus:outline-none focus:border-[#214C43] appearance-none bg-white cursor-pointer"
                >
                  <option value="all">All Statuses</option>
                  {(['new','called','site_visit_scheduled','converted','not_interested'] as LeadStatus[]).map(s => (
                    <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                  ))}
                </select>
                <ChevronDown className="w-4 h-4 text-stone-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Package Filter */}
              <div className="relative">
                <Package2 className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  value={filterPkg}
                  onChange={e => setFilterPkg(e.target.value)}
                  className="pl-9 pr-8 py-2 text-sm border border-stone-200 rounded-lg focus:outline-none focus:border-[#214C43] appearance-none bg-white cursor-pointer"
                >
                  <option value="all">All Packages</option>
                  <option value="classic">Classic</option>
                  <option value="pure">Pure</option>
                  <option value="premium">Premium</option>
                  <option value="bespoke">Bespoke</option>
                </select>
                <ChevronDown className="w-4 h-4 text-stone-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs text-stone-500 mr-1">{filteredLeads.length} leads</span>
              <button
                onClick={exportExcel}
                className="flex items-center gap-1.5 text-xs bg-emerald-700 hover:bg-emerald-800 text-white px-3.5 py-2 rounded-lg transition-colors font-medium cursor-pointer shadow-xs"
                title="Export as Microsoft Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                Export Excel (.xlsx)
              </button>
              <button
                onClick={exportCSV}
                className="flex items-center gap-1.5 text-xs bg-[#214C43] text-white px-3.5 py-2 rounded-lg hover:bg-[#3B0F1A] transition-colors font-medium cursor-pointer shadow-xs"
                title="Export as CSV (.csv)"
              >
                <Download className="w-3.5 h-3.5" />
                Export CSV
              </button>
            </div>

          </div>
        </div>

        {/* Leads Table */}
        <div className="bg-white rounded-xl border border-stone-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-stone-50 border-b border-stone-200">
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Date</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Name</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Phone</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Location</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Size</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Package</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Status</th>
                  <th className="text-left px-4 py-3 text-xs font-semibold text-stone-500 uppercase tracking-wide">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredLeads.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-12 text-stone-400">
                      <TrendingUp className="w-10 h-10 mx-auto mb-2 opacity-30" />
                      <p>No leads found matching your filters.</p>
                    </td>
                  </tr>
                ) : (
                  filteredLeads.map(lead => (
                    <tr key={lead.id} className="hover:bg-stone-50 transition-colors">
                      <td className="px-4 py-3 text-xs text-stone-500 whitespace-nowrap">
                        {new Date(lead.created_at).toLocaleDateString('en-IN', {
                          day: '2-digit', month: 'short', year: 'numeric',
                        })}
                        <br />
                        <span className="text-stone-400">
                          {new Date(lead.created_at).toLocaleTimeString('en-IN', {
                            hour: '2-digit', minute: '2-digit',
                          })}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-medium text-stone-900">{cleanText(lead.name)}</td>
                      <td className="px-4 py-3">
                        <a
                          href={`tel:+91${lead.phone}`}
                          className="flex items-center gap-1.5 text-stone-700 hover:text-[#214C43] font-mono text-xs"
                        >
                          <Phone className="w-3.5 h-3.5" />
                          {cleanText(lead.phone)}
                        </a>
                      </td>
                      <td className="px-4 py-3 text-stone-600 max-w-[150px] truncate" title={cleanText(lead.plot_location)}>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 flex-shrink-0 text-stone-400" />
                          {cleanText(lead.plot_location)}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-stone-600 text-xs">{cleanText(lead.plot_size)}</td>
                      <td className="px-4 py-3 text-xs text-stone-600 max-w-[120px] truncate" title={cleanText(lead.package_interest)}>
                        {cleanText(lead.package_interest)}
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex flex-col gap-1.5">
                          <StatusBadge status={lead.status} />
                          <StatusDropdown
                            leadId={lead.id}
                            current={lead.status}
                            onChange={handleStatusChange}
                          />
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <a
                            href={waUrl(lead)}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs bg-[#25D366] hover:bg-[#20bd5a] text-white px-2.5 py-1.5 rounded-lg transition-colors font-medium whitespace-nowrap"
                            title="Open WhatsApp"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            WhatsApp
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
};
