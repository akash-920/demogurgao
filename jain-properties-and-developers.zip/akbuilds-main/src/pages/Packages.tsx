import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ShieldCheck, ArrowRight, Calculator, HelpCircle, Plus, Minus
} from 'lucide-react';
import { packageTiers, packageCategories } from '../data/packageData';
import { FloorDropdown, FLOOR_OPTIONS, FloorOption } from '../components/FloorDropdown';
import { PackageDropdown } from '../components/PackageDropdown';

interface PackagesProps {
  onOpenConsultation: (packageName?: string) => void;
}

export const Packages: React.FC<PackagesProps> = ({ onOpenConsultation }) => {
  // Accordion state for per-card category dropdowns
  
  // Package Cost Estimator Required Fields State
  const [selectedPackageTierId, setSelectedPackageTierId] = useState<string>('pure');
  const [floorAreaInput, setFloorAreaInput] = useState<string>('1800'); // Plot area / area per floor
  const [selectedFloorOption, setSelectedFloorOption] = useState<FloorOption>(FLOOR_OPTIONS[2]); // Default G+2

  // State for per-card category accordion dropdowns (key: "tierId-categoryId")
  const [expandedCardCategories, setExpandedCardCategories] = useState<Record<string, boolean>>({});

  // Math Calculations for Cost Estimator
  const numericFloorArea = Math.max(0, parseInt(floorAreaInput.replace(/[^0-9]/g, ''), 10) || 0);
  const totalBuiltUpArea = numericFloorArea * selectedFloorOption.multiplier;

  const selectedEstimatorPackageObj = packageTiers.find(p => p.id === selectedPackageTierId) || packageTiers[1];
  const baseCost = totalBuiltUpArea * selectedEstimatorPackageObj.price;
  const gstCost = Math.round(baseCost * 0.18);
  const grandTotalCost = baseCost + gstCost;




  const toggleCardCategory = (tierId: string, categoryId: string) => {
    const key = `${tierId}-${categoryId}`;
    setExpandedCardCategories(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };


  const formatLakhs = (amount: number) => {
    if (amount >= 10000000) {
      return `₹${(amount / 10000000).toFixed(2)} Cr`;
    }
    return `₹${(amount / 100000).toFixed(2)} Lakhs`;
  };

  const presetAreas = [1000, 1800, 2500, 3500, 5000];

  return (
    <div className="space-y-0 bg-[#F7F5EF]">
      {/* Header Banner */}
      <section className="bg-[#173B35] text-[#F7F5EF] py-16 md:py-20 border-b border-[#E7B86A]/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-blueprint opacity-60 pointer-events-none" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#214C43] border border-[#E7B86A]/40 text-[#E7B86A] text-xs font-semibold uppercase tracking-widest">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Exact Transparent Itemized Pricing</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-cinzel font-bold text-[#F7F5EF]">
            Construction Packages & Specifications
          </h1>
          <p className="text-stone-300 text-sm sm:text-base max-w-2xl mx-auto font-light leading-relaxed">
            Select a package tier, enter floor dimensions, and choose the number of floors to calculate total construction estimates across Classic, Pure, and Premium packages.
          </p>
        </div>
      </section>

      {/* PACKAGE COST ESTIMATOR & CARDS SECTION */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* PACKAGE COST ESTIMATOR CONTROL BAR (WITH REDESIGNED PACKAGE DROPDOWN & NUMBER OF FLOORS DROPDOWN) */}
        <div className="bg-[#173B35] text-[#F7F5EF] p-6 md:p-8 rounded-2xl border border-[#E7B86A]/40 shadow-2xl space-y-6 relative overflow-visible">
          <div className="absolute inset-0 bg-blueprint opacity-40 pointer-events-none rounded-2xl" />

          <div className="relative space-y-6">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#E7B86A]/30 pb-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
                  <Calculator className="w-4 h-4" />
                  <span>Package Cost Estimator</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#F7F5EF]">
                  Construction Budget Calculator
                </h2>
              </div>
              <span className="text-xs text-[#E7B86A] bg-[#3B0F1A] px-3.5 py-1.5 rounded-full border border-[#E7B86A]/30 font-medium">
                Real-Time Floor Multiplier Calculation
              </span>
            </div>

            {/* Estimator Inputs Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-[#3B0F1A] p-6 rounded-2xl border border-[#E7B86A]/30 items-end">
              
              {/* Field 1: Redesigned Custom Package Tier Dropdown Selector */}
              <div className="md:col-span-4 space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#E7B86A]">
                  1. Select Package Tier <span className="text-red-400">*</span>
                </label>
                <PackageDropdown
                  packageTiers={packageTiers}
                  selectedTierId={selectedPackageTierId}
                  onChange={(tierId) => {
                    setSelectedPackageTierId(tierId);
                  }}
                />
              </div>

              {/* Field 2: Plot Area / Floor Area Input */}
              <div className="md:col-span-4 space-y-1.5">
                <label htmlFor="estimator-area-input" className="block text-xs font-bold uppercase tracking-wider text-[#E7B86A]">
                  2. Area Per Floor (Sq. Ft.) <span className="text-red-400">*</span>
                </label>
                <div className="relative">
                  <input
                    id="estimator-area-input"
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={floorAreaInput}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === '' || /^\d+$/.test(val)) {
                        setFloorAreaInput(val);
                      }
                    }}
                    placeholder="e.g. 1800"
                    className="w-full px-4 py-3.5 bg-[#4B1120] text-[#F8F6F2] font-serif font-bold text-base rounded-[20px] border border-[#C8A45D] shadow-lg focus:outline-none focus:ring-2 focus:ring-[#C8A45D]/50"
                  />
                  <span className="absolute right-4 top-3.5 text-xs text-[#E7B86A] font-bold">
                    Sq.Ft
                  </span>
                </div>
              </div>

              {/* Field 3: Redesigned Custom Number of Floors Dropdown */}
              <div className="md:col-span-4 space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#E7B86A]">
                  3. Number of Floors <span className="text-red-400">*</span>
                </label>
                <FloorDropdown
                  selectedOption={selectedFloorOption}
                  onChange={(opt) => setSelectedFloorOption(opt)}
                />
              </div>

            </div>

            {/* Quick Area Presets */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-stone-300">
              <span className="text-[#E7B86A] font-bold uppercase tracking-wider">Quick Area Presets:</span>
              {presetAreas.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setFloorAreaInput(preset.toString())}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    numericFloorArea === preset
                      ? 'bg-[#E7B86A] text-[#173B35] border-[#E7B86A]'
                      : 'bg-[#3B0F1A] text-stone-300 border-stone-700 hover:border-[#E7B86A]'
                  }`}
                >
                  {preset.toLocaleString('en-IN')} sq.ft
                </button>
              ))}
            </div>

            {/* DYNAMIC ESTIMATE RESULTS DISPLAY BOX */}
            <div className="p-6 bg-[#3B0F1A] rounded-2xl border border-[#E7B86A]/40 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-center">
              <div>
                <div className="text-xs text-stone-400 font-semibold uppercase">Total Built-Up Area</div>
                <div className="text-xl font-serif font-bold text-[#F7F5EF] mt-0.5">
                  {totalBuiltUpArea.toLocaleString('en-IN')} Sq. Ft.
                </div>
                <div className="text-[11px] text-[#E7B86A]">
                  ({numericFloorArea} sq.ft × {selectedFloorOption.title} [{selectedFloorOption.code}])
                </div>
              </div>

              <div>
                <div className="text-xs text-stone-400 font-semibold uppercase">Base Construction Cost</div>
                <div className="text-xl font-serif font-bold text-[#F7F5EF] mt-0.5">
                  ₹{baseCost.toLocaleString('en-IN')}
                </div>
                <div className="text-[11px] text-stone-400">
                  @{selectedEstimatorPackageObj.name} Rate ₹{selectedEstimatorPackageObj.price}/sq.ft
                </div>
              </div>

              <div>
                <div className="text-xs text-stone-400 font-semibold uppercase">GST @ 18%</div>
                <div className="text-xl font-serif font-bold text-stone-300 mt-0.5">
                  ₹{gstCost.toLocaleString('en-IN')}
                </div>
                <div className="text-[11px] text-stone-400">Statutory tax element</div>
              </div>

              <div className="p-4 bg-[#173B35] rounded-xl border border-[#E7B86A]/50 text-center sm:text-right">
                <div className="text-xs text-stone-400 font-bold uppercase">Estimated Investment</div>
                <div className="text-2xl sm:text-3xl font-cinzel font-bold text-[#E7B86A] mt-0.5">
                  {formatLakhs(baseCost)}
                </div>
                <div className="text-[10px] text-stone-400">
                  (₹{baseCost.toLocaleString('en-IN')} + GST extra)
                </div>
              </div>
            </div>

            {/* CTA to Consultation */}
            <div className="pt-2 text-right">
              <button
                type="button"
                onClick={() => onOpenConsultation(`${selectedEstimatorPackageObj.name} Package (${totalBuiltUpArea} Sq.Ft across ${selectedFloorOption.title} [${selectedFloorOption.code}] - Estimated ${formatLakhs(grandTotalCost)})`)}
                className="px-6 py-3.5 bg-[#E7B86A] hover:bg-[#D5A854] text-[#173B35] font-bold text-xs uppercase tracking-widest rounded-xl shadow-lg transition-all inline-flex items-center gap-2 cursor-pointer border border-[#F7F5EF]/30"
              >
                <span>Request Written Estimate for {totalBuiltUpArea} Sq.Ft ({selectedFloorOption.code})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

        {/* 3 Package Cards Displayed Side by Side */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {packageTiers.map((tier) => {
            
            // Calculations for this card based on selected built-up area and floor configuration
            const cardBaseCost = totalBuiltUpArea * tier.price;
            const cardGstCost = Math.round(cardBaseCost * 0.18);
            const cardGrandTotal = cardBaseCost + cardGstCost;

            return (
              <motion.div
                key={tier.id}
                whileHover={{ y: -6 }}
                className="bg-white rounded-2xl border transition-all duration-300 shadow-luxury flex flex-col justify-between relative overflow-hidden border-[#E7DFD5]"
              >
                {/* Colored Header Banner */}
                <div className={`px-6 py-4 text-white font-bold text-base ${
                  tier.id === 'classic' ? 'bg-[#214C43]' : tier.id === 'pure' ? 'bg-[#E7B86A]' : 'bg-[#72202E]'
                }`}>
                  <span>{tier.name} – ₹ {tier.price.toLocaleString('en-IN')}/sqft + GST</span>
                </div>

                <div className="p-6 space-y-4 flex-1">

                  {/* Category Accordion Dropdowns */}
                  <div className="border-t border-stone-200">
                    <div className="divide-y divide-stone-100">
                      {packageCategories.map((category) => {
                        const catKey = `${tier.id}-${category.id}`;
                        const isCatExpanded = expandedCardCategories[catKey] || false;
                        const tierSpecKey: 'classic' | 'pure' | 'premium' = tier.id === 'classic' ? 'classic' : tier.id === 'pure' ? 'pure' : 'premium';

                        return (
                          <div key={category.id}>
                            <button
                              type="button"
                              onClick={() => toggleCardCategory(tier.id, category.id)}
                              className="w-full flex items-center justify-between py-3 px-1 text-left cursor-pointer hover:bg-stone-50 transition-colors group"
                            >
                              <span className="text-sm font-bold text-[#214C43] group-hover:text-[#E7B86A] transition-colors">
                                {category.name}
                              </span>
                              {isCatExpanded ? (
                                <Minus className="w-4 h-4 text-[#E7B86A] shrink-0" />
                              ) : (
                                <Plus className="w-4 h-4 text-[#214C43] group-hover:text-[#E7B86A] shrink-0 transition-colors" />
                              )}
                            </button>
                            <AnimatePresence initial={false}>
                              {isCatExpanded && (
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: 'auto', opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  transition={{ duration: 0.25, ease: 'easeInOut' }}
                                  className="overflow-hidden"
                                >
                                  <ul className="pb-3 pl-1 pr-1 space-y-2">
                                    {category.items.map((item, itemIdx) => (
                                      <li key={itemIdx} className="text-xs text-stone-600 leading-relaxed pl-3 border-l-2 border-[#E7B86A]/30">
                                        <span className="font-semibold text-[#214C43]">{item.feature}:</span>{' '}
                                        {item[tierSpecKey]}
                                      </li>
                                    ))}
                                  </ul>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="p-8 pt-4 space-y-3">
                  <p className="text-center text-xs text-stone-400">Get in touch with us!</p>
                  <button
                    onClick={() => onOpenConsultation(`${tier.name} Package (${totalBuiltUpArea} Sq.Ft across ${selectedFloorOption.title} [${selectedFloorOption.code}] - Estimated ${formatLakhs(cardGrandTotal)})`)}
                    className="w-full py-3 px-4 bg-[#E7B86A] hover:bg-[#D5A854] text-[#173B35] font-bold text-xs uppercase tracking-wider rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Talk To Our Expert</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>


      </section>

      {/* FAQs Section */}
      <section className="py-12 bg-[#F4EFEA] border-t border-[#E7DFD5]">
        <div className="max-w-4xl mx-auto px-4 space-y-6">
          <div className="text-center space-y-2">
            <HelpCircle className="w-8 h-8 text-[#E7B86A] mx-auto" />
            <h3 className="text-2xl font-serif font-bold text-[#214C43]">
              Package & Pricing FAQs
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-stone-700">
            <div className="p-4 bg-white rounded-lg border border-[#E7DFD5] space-y-1">
              <div className="font-bold text-[#214C43]">Are architectural drawings included?</div>
              <p className="font-light">Yes! All packages include 2D floor plans, electrical drawings, structural details, and 3D exterior renderings.</p>
            </div>
            <div className="p-4 bg-white rounded-lg border border-[#E7DFD5] space-y-1">
              <div className="font-bold text-[#214C43]">How are payment stages structured?</div>
              <p className="font-light">Payments are tied strictly to physical construction milestones (e.g. Plinth, Slab 1, Masonry, Plaster, Handover).</p>
            </div>
            <div className="p-4 bg-white rounded-lg border border-[#E7DFD5] space-y-1">
              <div className="font-bold text-[#214C43]">Can I customize materials inside a package?</div>
              <p className="font-light">Absolutely. We provide itemized rate adjustments if you wish to upgrade specific tiles, fixtures, or door designs.</p>
            </div>
            <div className="p-4 bg-white rounded-lg border border-[#E7DFD5] space-y-1">
              <div className="font-bold text-[#214C43]">What is the post-construction warranty?</div>
              <p className="font-light">We provide a 10-year structural & waterproofing warranty alongside manufacturer warranties for all installed hardware.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
