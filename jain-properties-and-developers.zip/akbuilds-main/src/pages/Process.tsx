import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Compass, TestTube, Grid, FileCheck2, Ruler, Box, 
  FileSignature, Key, ShieldCheck, CheckCircle2, Sparkles 
} from 'lucide-react';
import { processStages } from '../data/processData';
import { ProcessStage } from '../types';

interface ProcessProps {
  onOpenConsultation: () => void;
}

export const Process: React.FC<ProcessProps> = ({ onOpenConsultation }) => {
  const [selectedStage, setSelectedStage] = useState<ProcessStage>(processStages[0]);

  const getStageIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass': return <Compass className="w-5 h-5" />;
      case 'TestTube': return <TestTube className="w-5 h-5" />;
      case 'Grid': return <Grid className="w-5 h-5" />;
      case 'FileCheck2': return <FileCheck2 className="w-5 h-5" />;
      case 'Ruler': return <Ruler className="w-5 h-5" />;
      case 'Box': return <Box className="w-5 h-5" />;
      case 'FileSignature': return <FileSignature className="w-5 h-5" />;
      case 'Key': return <Key className="w-5 h-5" />;
      default: return <CheckCircle2 className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-0 bg-[#F7F5EF]">
      {/* Header Banner */}
      <section className="bg-[#173B35] text-[#F7F5EF] py-16 md:py-20 border-b border-[#E7B86A]/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-blueprint opacity-60 pointer-events-none" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#214C43] border border-[#E7B86A]/40 text-[#E7B86A] text-xs font-semibold uppercase tracking-widest">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Exact Presentation Roadmap</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-cinzel font-bold text-[#F7F5EF]">
            Our 8-Stage Execution Process
          </h1>
          <p className="text-stone-300 text-sm sm:text-base max-w-2xl mx-auto font-light leading-relaxed">
            From digital plot surveys to final key handover—every phase is meticulously engineered to ensure on-time project delivery and strict budget control.
          </p>
        </div>
      </section>

      {/* Main Interactive Stage Inspector Section */}
      <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Stage Selection Navigation Bar / Grid */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-serif font-bold text-[#214C43]">
              Select Stage to Inspect Details:
            </h2>
            <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-wider hidden sm:block">
              Stage {selectedStage.step} of 8
            </div>
          </div>

          {/* Connected Horizontal Stage Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {processStages.map((stage) => {
              const isSelected = selectedStage.step === stage.step;
              return (
                <button
                  key={stage.step}
                  onClick={() => setSelectedStage(stage)}
                  className={`p-3 rounded-xl text-left border transition-all duration-200 cursor-pointer relative flex flex-col justify-between h-28 ${
                    isSelected
                      ? 'bg-[#214C43] text-[#F7F5EF] border-[#E7B86A] shadow-lg scale-102 ring-2 ring-[#E7B86A]/50'
                      : 'bg-white text-stone-800 border-[#E7DFD5] hover:border-[#E7B86A] hover:bg-stone-50 shadow-xs'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      isSelected ? 'bg-[#E7B86A] text-[#173B35]' : 'bg-stone-100 text-[#214C43]'
                    }`}>
                      0{stage.step}
                    </span>
                    <div className={isSelected ? 'text-[#E7B86A]' : 'text-[#214C43]'}>
                      {getStageIcon(stage.icon)}
                    </div>
                  </div>

                  <div className="mt-2">
                    <div className="text-xs font-serif font-bold line-clamp-2 leading-snug">
                      {stage.title}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Expanded Stage Inspection Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedStage.step}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="bg-[#173B35] text-[#F7F5EF] rounded-2xl border border-[#E7B86A]/40 p-6 md:p-10 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-blueprint opacity-40 pointer-events-none" />

            <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              
              {/* Left Stage Overview */}
              <div className="lg:col-span-7 space-y-5">
                <div className="flex items-center gap-3">
                  <span className="w-12 h-12 rounded-xl bg-[#214C43] text-[#E7B86A] border border-[#E7B86A]/50 flex items-center justify-center font-cinzel font-bold text-xl shadow-md">
                    0{selectedStage.step}
                  </span>
                  <div>
                    <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-widest">
                      {selectedStage.subtitle}
                    </div>
                    <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#F7F5EF]">
                      Stage {selectedStage.step}: {selectedStage.title}
                    </h3>
                  </div>
                </div>

                <p className="text-stone-300 text-sm sm:text-base font-light leading-relaxed">
                  {selectedStage.description}
                </p>

                {/* Deliverables Checklist */}
                <div className="space-y-2 pt-2 border-t border-[#E7B86A]/20">
                  <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Stage Deliverables & Documentation</span>
                  </div>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-200">
                    {selectedStage.deliverables.map((item, dIdx) => (
                      <li key={dIdx} className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Right Stage Metrics & Action */}
              <div className="lg:col-span-5 bg-[#3B0F1A] p-6 rounded-xl border border-[#E7B86A]/30 space-y-6">
                <div className="space-y-4">
                  <div>
                    <div className="text-xs text-stone-400 uppercase tracking-wider font-semibold">
                      Estimated Phase Duration
                    </div>
                    <div className="text-xl font-serif font-bold text-[#E7B86A]">
                      {selectedStage.durationEstimate || '1 - 3 Days'}
                    </div>
                  </div>

                  {selectedStage.keyMetric && (
                    <div>
                      <div className="text-xs text-stone-400 uppercase tracking-wider font-semibold">
                        Key Performance Benchmark
                      </div>
                      <div className="text-lg font-medium text-[#F7F5EF]">
                        {selectedStage.keyMetric}
                      </div>
                    </div>
                  )}
                </div>

                {/* Next / Previous Buttons */}
                <div className="pt-4 border-t border-[#E7B86A]/20 flex items-center justify-between gap-3">
                  <button
                    disabled={selectedStage.step === 1}
                    onClick={() => setSelectedStage(processStages[selectedStage.step - 2])}
                    className="px-4 py-2 bg-[#214C43] text-[#F7F5EF] text-xs font-semibold rounded-lg disabled:opacity-40 hover:bg-[#214C43] transition-colors cursor-pointer"
                  >
                    ← Previous
                  </button>

                  <button
                    onClick={onOpenConsultation}
                    className="px-4 py-2 bg-[#E7B86A] text-[#173B35] text-xs font-bold uppercase rounded-lg hover:bg-[#D5A854] transition-colors cursor-pointer"
                  >
                    Start From Stage {selectedStage.step}
                  </button>

                  <button
                    disabled={selectedStage.step === 8}
                    onClick={() => setSelectedStage(processStages[selectedStage.step])}
                    className="px-4 py-2 bg-[#214C43] text-[#F7F5EF] text-xs font-semibold rounded-lg disabled:opacity-40 hover:bg-[#214C43] transition-colors cursor-pointer"
                  >
                    Next Stage →
                  </button>
                </div>
              </div>

            </div>
          </motion.div>
        </AnimatePresence>

        {/* Connected Vertical Timeline View for Mobile & Full Print Overview */}
        <div className="space-y-8 pt-8 border-t border-stone-300">
          <div className="text-center space-y-2">
            <h3 className="text-2xl font-serif font-bold text-[#214C43]">
              Full 8-Stage Timeline Overview
            </h3>
            <p className="text-stone-600 text-xs font-light">
              Scroll through the entire sequential execution plan from site survey to key handover.
            </p>
          </div>

          <div className="relative border-l-2 border-[#E7B86A] ml-4 sm:ml-8 lg:ml-12 space-y-8 pl-6 sm:pl-10">
            {processStages.map((stage) => (
              <div key={stage.step} className="relative group">
                {/* Connected Dot */}
                <div className="absolute -left-[31px] sm:-left-[47px] top-1.5 w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-[#214C43] border-2 border-[#E7B86A] text-[#E7B86A] flex items-center justify-center font-bold text-xs shadow-md">
                  0{stage.step}
                </div>

                <div className="bg-white p-5 rounded-xl border border-[#E7DFD5] shadow-xs space-y-2 hover:border-[#E7B86A] transition-colors">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="text-lg font-serif font-bold text-[#214C43] flex items-center gap-2">
                      <span>Stage {stage.step}: {stage.title}</span>
                      <span className="text-xs text-[#E7B86A] font-normal italic">({stage.subtitle})</span>
                    </h4>
                    <span className="text-xs font-bold text-[#214C43] bg-stone-100 px-2.5 py-1 rounded-md border border-stone-200">
                      {stage.durationEstimate}
                    </span>
                  </div>

                  <p className="text-stone-600 text-xs sm:text-sm font-light leading-relaxed">
                    {stage.description}
                  </p>

                  <div className="flex flex-wrap items-center gap-2 pt-2 text-[11px] text-stone-500 border-t border-stone-100">
                    <span className="font-semibold text-[#214C43]">Deliverables:</span>
                    {stage.deliverables.join(' • ')}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </section>

      {/* Consultation Banner */}
      <section className="py-12 bg-[#173B35] text-[#F7F5EF] text-center border-t border-[#E7B86A]/30">
        <div className="max-w-3xl mx-auto px-4 space-y-4">
          <h3 className="text-2xl font-serif font-bold text-[#F7F5EF]">
            Want a Custom Project Timeline for Your Plot?
          </h3>
          <p className="text-stone-300 text-sm font-light">
            Our engineers will create an exact milestone chart based on your plot dimensions and architectural scope.
          </p>
          <div className="pt-2">
            <button
              onClick={onOpenConsultation}
              className="px-8 py-3.5 bg-[#E7B86A] hover:bg-[#D5A854] text-[#173B35] font-bold text-xs uppercase tracking-widest rounded-lg shadow-md transition-all border border-[#F7F5EF]/30 cursor-pointer"
            >
              Get Custom Project Timeline
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
