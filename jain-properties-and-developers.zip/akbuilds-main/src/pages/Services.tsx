import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Building2, Sparkles, ClipboardCheck, ArrowRight, ShieldCheck, CheckCircle2, Shield, Wrench } from 'lucide-react';
import { servicesData } from '../data/servicesData';

interface ServicesProps {
  onOpenConsultation: () => void;
}

export const Services: React.FC<ServicesProps> = ({ onOpenConsultation }) => {
  const location = useLocation();

  useEffect(() => {
    if (location.hash) {
      const el = document.querySelector(location.hash);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.scrollTo(0, 0);
    }
  }, [location]);

  return (
    <div className="space-y-0 bg-[#F7F5EF]">
      {/* Header Banner */}
      <section className="bg-[#173B35] text-[#F7F5EF] py-16 md:py-20 border-b border-[#E7B86A]/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-blueprint opacity-60 pointer-events-none" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#214C43] border border-[#E7B86A]/40 text-[#E7B86A] text-xs font-semibold uppercase tracking-widest">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Turnkey Engineering & Interior Architecture</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-cinzel font-bold text-[#F7F5EF]">
            Our Core Verticals
          </h1>
          <p className="text-stone-300 text-sm sm:text-base max-w-2xl mx-auto font-light leading-relaxed">
            Delivering structural safety, bespoke craftsmanship, and rigorous third-party management across your area.
          </p>
        </div>
      </section>

      {/* Services List Section */}
      <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
        {servicesData.map((service, index) => {
          const isEven = index % 2 === 0;
          
          return (
            <div
              id={service.id}
              key={service.id}
              className={`grid grid-cols-1 lg:grid-cols-12 gap-12 items-center scroll-mt-28 ${
                !isEven ? 'lg:flex-row-reverse' : ''
              }`}
            >
              {/* Image Column */}
              <div className={`lg:col-span-6 ${!isEven ? 'lg:order-2' : 'lg:order-1'}`}>
                <div className="relative rounded-xl overflow-hidden shadow-2xl border border-[#E7B86A]/30 group">
                  <img
                    src={service.heroImage}
                    alt={service.title}
                    className="w-full h-[400px] sm:h-[480px] object-cover transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#173B35]/80 via-transparent to-transparent" />
                  
                  <div className="absolute top-6 left-6 p-3 bg-[#214C43] text-[#E7B86A] rounded-xl shadow-lg border border-[#E7B86A]/40">
                    {service.id === 'construction' && <Building2 className="w-8 h-8" />}
                    {service.id === 'interiors' && <Sparkles className="w-8 h-8" />}
                    {service.id === 'project-management' && <ClipboardCheck className="w-8 h-8" />}
                  </div>

                  <div className="absolute bottom-6 left-6 right-6 text-[#F7F5EF]">
                    <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-wider mb-1">
                      Vertical Overview
                    </div>
                    <div className="font-serif text-xl font-bold">
                      {service.title}
                    </div>
                  </div>
                </div>
              </div>

              {/* Text Specs Column */}
              <div className={`lg:col-span-6 space-y-6 ${!isEven ? 'lg:order-1' : 'lg:order-2'}`}>
                <div className="inline-flex items-center gap-2 text-[#E7B86A] text-xs font-bold uppercase tracking-widest">
                  <span className="w-8 h-0.5 bg-[#E7B86A]" />
                  <span>Vertical 0{index + 1}</span>
                </div>

                <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#214C43]">
                  {service.title}
                </h2>

                <p className="text-[#E7B86A] font-medium text-sm sm:text-base italic">
                  “{service.tagline}”
                </p>

                <p className="text-stone-700 text-sm sm:text-base leading-relaxed font-light">
                  {service.description}
                </p>

                {/* Key Features Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  {service.features.map((feat, fIdx) => (
                    <div key={fIdx} className="p-3.5 bg-white rounded-lg border border-[#E7DFD5] shadow-xs space-y-1">
                      <div className="font-serif font-bold text-[#214C43] text-sm flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-[#E7B86A] shrink-0" />
                        <span>{feat.title}</span>
                      </div>
                      <p className="text-xs text-stone-600 font-light leading-snug">
                        {feat.desc}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Specifications List */}
                <div className="p-4 rounded-xl bg-[#173B35] text-[#F7F5EF] border border-[#E7B86A]/30 space-y-2">
                  <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-wider flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    <span>Material & Engineering Standards Included</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-stone-300 pt-1">
                    {service.specifications.map((spec, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#E7B86A] shrink-0" />
                        <span>{spec}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <div className="pt-2">
                  <button
                    onClick={onOpenConsultation}
                    className="px-6 py-3.5 bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] font-semibold text-xs uppercase tracking-wider rounded-lg shadow-md transition-all border border-[#E7B86A]/40 flex items-center gap-2 cursor-pointer"
                  >
                    <span>Consult Our {service.title} Team</span>
                    <ArrowRight className="w-4 h-4 text-[#E7B86A]" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </section>

      {/* Bottom Guarantee Banner */}
      <section className="py-12 bg-[#F4EFEA] border-t border-[#E7DFD5] text-center">
        <div className="max-w-4xl mx-auto px-4 space-y-4">
          <Wrench className="w-8 h-8 text-[#E7B86A] mx-auto" />
          <h3 className="text-2xl font-serif font-bold text-[#214C43]">
            Need a Custom Combined Construction & Interior Package?
          </h3>
          <p className="text-stone-600 text-sm max-w-xl mx-auto font-light">
            We offer turnkey packages combining gray-structure civil work with complete interior design at preferential bundled rates.
          </p>
          <div className="pt-2">
            <button
              onClick={onOpenConsultation}
              className="px-8 py-3.5 bg-[#E7B86A] hover:bg-[#D5A854] text-[#173B35] font-bold text-xs uppercase tracking-widest rounded-lg shadow-md transition-all border border-[#F7F5EF]/30 cursor-pointer"
            >
              Request Custom Quote
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
