import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Send, CheckCircle2, ShieldCheck, Clock, Building2, User } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    plotLocation: '',
    plotSize: '',
    serviceRequired: 'Construction & Interiors',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 800);
  };

  return (
    <div className="space-y-0 bg-[#F7F5EF]">
      {/* Header Banner */}
      <section className="bg-[#173B35] text-[#F7F5EF] py-16 md:py-20 border-b border-[#E7B86A]/30 relative overflow-hidden">
        <div className="absolute inset-0 bg-blueprint opacity-60 pointer-events-none" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#214C43] border border-[#E7B86A]/40 text-[#E7B86A] text-xs font-semibold uppercase tracking-widest">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Property Consultation Desk</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-cinzel font-bold text-[#F7F5EF]">
            GET IN TOUCH
          </h1>
          <p className="text-[#E7B86A] text-lg font-serif italic">
            “Let’s build your vision, step by step.”
          </p>
        </div>
      </section>

      {/* Main Contact Section */}
      <section className="py-16 md:py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Direct Contacts & Office Map */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-3">
              <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-widest">
                Immediate Direct Connect
              </div>
              <h2 className="text-3xl font-serif font-bold text-[#214C43]">
                Speak to Our Property Team
              </h2>
              <p className="text-stone-600 text-sm font-light leading-relaxed">
                Connect directly with our leadership team for technical inquiries, site visits, or quotation reviews.
              </p>
            </div>

            {/* Click to Call Property Team Cards - Identical Styling */}
            <div className="space-y-4">
              
              {/* Our Team Card */}
              <a
                href="tel:+919810155668"
                className="block p-5 bg-white rounded-xl border border-[#E7DFD5] shadow-luxury shadow-luxury-hover hover:border-[#E7B86A] transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-lg bg-[#214C43] text-[#E7B86A] shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-serif font-bold text-lg text-[#214C43]">
                      Our Team
                    </div>
                    <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-widest">
                      Property Team
                    </div>
                    <div className="text-sm font-bold text-stone-800 mt-1">
                      +91 90000 00000
                    </div>
                  </div>
                </div>
              </a>

              {/* Property Consultant Card */}
              <a
                href="tel:+918447219897"
                className="block p-5 bg-white rounded-xl border border-[#E7DFD5] shadow-luxury shadow-luxury-hover hover:border-[#E7B86A] transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-lg bg-[#214C43] text-[#E7B86A] shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-serif font-bold text-lg text-[#214C43]">
                      Property Consultant
                    </div>
                    <div className="text-xs font-bold text-[#E7B86A] uppercase tracking-widest">
                      Property Team
                    </div>
                    <div className="text-sm font-bold text-stone-800 mt-1">
                      +91 90000 00000
                    </div>
                  </div>
                </div>
              </a>

              {/* Email Card */}
              <a
                href="mailto:contact@jainproperties.com"
                className="block p-5 bg-white rounded-xl border border-[#E7DFD5] shadow-luxury shadow-luxury-hover hover:border-[#E7B86A] transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="p-3 rounded-lg bg-[#214C43] text-[#E7B86A] shrink-0">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-stone-500 uppercase">
                      Official Email
                    </div>
                    <div className="text-sm font-bold text-[#214C43]">
                      contact@jainproperties.com
                    </div>
                  </div>
                </div>
              </a>

            </div>

            {/* Office Address & Map Card */}
            <div className="p-6 bg-[#173B35] text-[#F7F5EF] rounded-xl border border-[#E7B86A]/40 space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-6 h-6 text-[#E7B86A] shrink-0 mt-1" />
                <div className="space-y-1">
                  <div className="font-serif font-bold text-lg text-[#E7B86A]">
                    Head Office
                  </div>
                  <p className="text-xs text-stone-300 leading-relaxed font-light">
                    91 Springboard, 90B Jaipur-Delhi Expy, Udyog Vihar, Sector 18, Gurugram, Sarhol, Haryana 122015.
                  </p>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs text-stone-400 border-t border-[#E7B86A]/20">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-[#E7B86A]" /> Mon - Sat: 9:30 AM - 7:00 PM
                </span>
                <span className="flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-[#E7B86A]" /> your city Hub
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Consultation Form */}
          <div className="lg:col-span-7 bg-white p-8 md:p-10 rounded-2xl border border-[#E7DFD5] shadow-xl space-y-6">
            <div className="space-y-1">
              <h3 className="text-2xl font-serif font-bold text-[#214C43]">
                Send Project Consultation Details
              </h3>
              <p className="text-stone-600 text-xs font-light">
                Fill in your plot location and scope. Our engineers will prepare a preliminary estimate.
              </p>
            </div>

            {submitted ? (
              <div className="p-8 bg-[#F7F5EF] rounded-xl border border-[#E7B86A] text-center space-y-4">
                <CheckCircle2 className="w-12 h-12 text-[#E7B86A] mx-auto" />
                <h4 className="text-2xl font-serif font-bold text-[#214C43]">
                  Message Received Successfully!
                </h4>
                <p className="text-stone-700 text-sm font-light max-w-md mx-auto">
                  Thank you <span className="font-bold">{formData.name}</span>. Our Team or Property Consultant will call you back at <span className="font-bold">{formData.phone}</span> shortly to discuss your <span className="font-bold">{formData.plotLocation}</span> build.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2 bg-[#214C43] text-[#F7F5EF] text-xs uppercase font-bold rounded-lg"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                      Your Full Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="e.g. Sangeeta Sharma"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      placeholder="+91 98101 XXXXX"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      placeholder="e.g. client@domain.com"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                      Service Required
                    </label>
                    <select
                      name="serviceRequired"
                      value={formData.serviceRequired}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                    >
                      <option value="Turnkey Construction">Turnkey Residential Construction</option>
                      <option value="Bespoke Interiors">Bespoke Modern Interiors</option>
                      <option value="Project Management (PMC)">Project Management Consultancy (PMC)</option>
                      <option value="Construction & Interiors">Turnkey Construction & Interiors Package</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                      Plot Location *
                    </label>
                    <input
                      type="text"
                      name="plotLocation"
                      required
                      placeholder="e.g. Your location"
                      value={formData.plotLocation}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                      Plot Size / Area
                    </label>
                    <input
                      type="text"
                      name="plotSize"
                      placeholder="e.g. 250 Sq. Yd."
                      value={formData.plotSize}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-[#214C43] mb-1">
                    Project Message / Specific Requirements
                  </label>
                  <textarea
                    name="message"
                    rows={4}
                    placeholder="Tell us about your timeline, expected basement/floors, or design preferences..."
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-[#F7F5EF] border border-stone-300 rounded-lg text-sm text-stone-900 focus:outline-none focus:border-[#214C43]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-[#214C43] hover:bg-[#3B0F1A] text-[#F7F5EF] font-bold text-xs uppercase tracking-widest rounded-lg shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer border border-[#E7B86A]/40"
                >
                  {loading ? (
                    <span>Submitting Project Details...</span>
                  ) : (
                    <>
                      <span>Submit Project Details</span>
                      <Send className="w-4 h-4 text-[#E7B86A]" />
                    </>
                  )}
                </button>
              </form>
            )}
          </div>

        </div>
      </section>
    </div>
  );
};
