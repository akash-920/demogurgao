import { ProcessStage } from '../types';

export const processStages: ProcessStage[] = [
  {
    step: 1,
    title: 'Digital Survey',
    subtitle: 'Site Boundary Mapping',
    description: 'Precision site boundary mapping, topographic contour and elevation surveys, and neighboring wall alignment checks using modern total-station digital land survey tools.',
    icon: 'Compass',
    deliverables: ['Total Station Contour Map', 'Boundary Dimension Verification Report', 'Plot Level Benchmark Marking'],
    durationEstimate: '1 - 2 Days',
    keyMetric: 'Sub-millimeter Survey Accuracy'
  },
  {
    step: 2,
    title: 'Soil Test',
    subtitle: 'Geotechnical Borehole Investigation',
    description: 'Geotechnical soil sampling at multiple depth intervals to calculate safe bearing capacity (SBC), water table depth, and foundation structural parameters.',
    icon: 'TestTube',
    deliverables: ['N-Value Borehole Log', 'SBC Report / Geotechnical Report', 'Recommended Foundation Type (Raft / Isolated / Pile)'],
    durationEstimate: '3 - 5 Days',
    keyMetric: 'Geotechnical SBC Analysis'
  },
  {
    step: 3,
    title: 'Floor Plan',
    subtitle: 'Architectural Layout & Flow',
    description: 'Bespoke 2D spatial architectural layout drafting optimizing sunlight, natural ventilation, room circulation, and optional Vastu Shastra directional alignment.',
    icon: 'Grid',
    deliverables: ['2D Floor Plans for All Levels', 'Furniture Layout Plan', 'Vastu Orientation Matrix'],
    durationEstimate: '5 - 7 Days',
    keyMetric: 'Optimized Living Space'
  },
  {
    step: 4,
    title: 'Approvals',
    subtitle: 'Municipal & Statutory Clearances',
    description: 'Compiling architectural submission sets, structural stability declarations, and liaison for local municipal plan approvals (MCG / DDA / NOIDA authority).',
    icon: 'FileCheck2',
    deliverables: ['Sanctioned Architectural Set', 'Structural Stability Declaration', 'Temporary Utility Meter Clearances'],
    durationEstimate: '10 - 20 Days',
    keyMetric: 'Seamless Legal Compliance'
  },
  {
    step: 5,
    title: 'Structural Drawing',
    subtitle: 'RCC & Engineering Detailing',
    description: 'Detailed structural engineering calculations for footings, columns, beam reinforcement schedules, slab rebar mesh, and seismic-compliant structural drawings.',
    icon: 'Ruler',
    deliverables: ['RCC Column & Footing Layout', 'Beam & Slab Rebar Schedules', 'Plinth Level & Water Tank Structural Design'],
    durationEstimate: '4 - 6 Days',
    keyMetric: 'Seismic-Compliant Engineering'
  },
  {
    step: 6,
    title: '3D Elevation',
    subtitle: 'Photorealistic Exterior Visuals',
    description: 'Creating photorealistic 3D visualizations of exterior facades with exact material texture mapping (stone cladding, louvers, lighting, CNC panels) prior to ground execution.',
    icon: 'Box',
    deliverables: ['High-Res 3D Exterior Renderings (Day/Night)', 'Material Palette Specification Board', 'Facade Lighting Concept'],
    durationEstimate: '4 - 7 Days',
    keyMetric: 'True-to-Life Pre-Visualization'
  },
  {
    step: 7,
    title: 'Agreement Signing',
    subtitle: 'Transparent Contract & Timeline',
    description: 'Execution of a formal itemized contract with fixed-price terms, detailed material brand matrix, milestone schedule, and contractual accountability clauses.',
    icon: 'FileSignature',
    deliverables: ['Legally Binding Master Construction Contract', 'Itemized Material Brand Matrix', 'Stage-wise Payment & Timeline Calendar'],
    durationEstimate: '1 - 2 Days',
    keyMetric: 'Strict Budget Control'
  },
  {
    step: 8,
    title: 'Project Handover',
    subtitle: 'Key Handover & As-Built Documentation',
    description: 'Formal key handover ceremony accompanied by warranty cards for all installed equipment, as-built MEP drawings, and post-handover warranty coverage.',
    icon: 'Key',
    deliverables: ['As-Built Architectural & MEP Drawings', 'Equipment & Material Warranty Dossier', 'Keys Ceremony & Post-Handover Care Guide'],
    durationEstimate: '1 Day',
    keyMetric: 'Turnkey Key Delivery'
  }
];
