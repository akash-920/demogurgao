import { PackageCategory, PackageTier } from '../types';

export const packageTiers: PackageTier[] = [
  {
    id: 'classic',
    name: 'CLASSIC',
    price: 2200,
    unit: '₹ / sq.ft + GST',
    tagline: 'Standard engineering precision with quality essential materials.',
    summaryInclusions: [
      'Rathi / Kamdhenu / JSW Steel',
      'Ultratech / Ambuja Cement – M25 RMC',
      'Tiles Upto ₹50/sqft (Living & Dining)',
      'JK Putty + Tractor Emulsion Painting',
      'Anchor / Roma Modular Switches',
      'Underground Sump – 3,000 Litres'
    ],
    highlightColor: 'border-stone-300'
  },
  {
    id: 'pure',
    name: 'PURE',
    price: 2600,
    unit: '₹ / sq.ft + GST',
    tagline: 'Enhanced finishes with superior structural grade materials & custom touches.',
    badge: 'MOST POPULAR',
    summaryInclusions: [
      'Rathi / Kamdhenu / JSW Steel',
      'Ultratech / Ambuja Cement – M25 RMC',
      'Tiles / Marble Upto ₹140/sqft (Living & Dining)',
      'JK Putty + Apcolite Premium Emulsion',
      'Legrand / Havells / Coral / Roma Switches',
      'Underground Sump – 7,000 Litres'
    ],
    highlightColor: 'border-[#E7B86A]'
  },
  {
    id: 'premium',
    name: 'PREMIUM',
    price: 3000,
    unit: '₹ / sq.ft + GST',
    tagline: 'Ultra-luxury architectural execution with premium finishes & bespoke details.',
    badge: 'LUXURY EDITION',
    summaryInclusions: [
      'Jindal / TATA / Panther Steel',
      'Ultratech / Ambuja Cement – M25 RMC',
      'Tiles / Marble Upto ₹250/sqft (Living & Dining)',
      'JK Putty + Royale Luxury Emulsion',
      'Schneider Unica Pure / Legrand / Jaquar Switches',
      'Underground Sump – 8,000 Litres'
    ],
    highlightColor: 'border-[#72202E]'
  }
];

export const packageCategories: PackageCategory[] = [
  {
    id: 'structure',
    name: 'Structure & Civil',
    iconName: 'Building2',
    items: [
      {
        feature: 'Steel (Rebar Grade)',
        classic: 'Rathi / Kamdhenu / JSW',
        pure: 'Rathi / Kamdhenu / JSW',
        premium: 'Jindal / TATA / Panther'
      },
      {
        feature: 'Cement Brand & Grade',
        classic: 'UltraTech Cement / Ambuja',
        pure: 'UltraTech Cement / Ambuja',
        premium: 'UltraTech Cement / Ambuja'
      },
      {
        feature: 'Aggregates',
        classic: '20mm / 40mm',
        pure: '20mm / 40mm',
        premium: '20mm / 40mm'
      },
      {
        feature: 'Brickwork & Walls',
        classic: 'Red Bricks',
        pure: 'Red Bricks',
        premium: 'Red Bricks'
      },
      {
        feature: 'Concrete Mix & Grade',
        classic: 'M25 RMC',
        pure: 'M25 RMC',
        premium: 'M25 RMC'
      },
      {
        feature: 'Floor-to-Floor Height',
        classic: '10 Feet (Finish Floor to Finished Floor)',
        pure: '10 Feet (Finish Floor to Finished Floor)',
        premium: '10 Feet (Finish Floor to Finished Floor)'
      }
    ]
  },
  {
    id: 'kitchen',
    name: 'Kitchen Specifications',
    iconName: 'ChefHat',
    items: [
      {
        feature: 'Wall Dado Tiles',
        classic: 'Upto ₹50 per sqft',
        pure: 'Upto ₹80 per sqft',
        premium: 'Tiles / Marble Upto ₹100 per sqft'
      },
      {
        feature: 'Main Sink Faucet',
        classic: 'Upto ₹2,000',
        pure: 'Upto ₹3,500',
        premium: 'Upto ₹5,000'
      },
      {
        feature: 'Faucets & Accessories',
        classic: 'Parryware / Hindware / Jaquar',
        pure: 'Parryware / Hindware / Jaquar',
        premium: 'Kohler / Parryware / Hindware / Jaquar'
      },
      {
        feature: 'Kitchen Sink',
        classic: 'Upto ₹4,000',
        pure: 'Upto ₹8,000',
        premium: 'Upto ₹12,000'
      },
      {
        feature: 'Modular Kitchen',
        classic: '₹3 Lakhs per kitchen with laminate',
        pure: '₹4 Lakhs per kitchen with laminate',
        premium: '₹6 Lakhs per kitchen with acrylic, hob and chimney'
      }
    ]
  },
  {
    id: 'bathroom',
    name: 'Bathroom & Plumbing',
    iconName: 'Bath',
    items: [
      {
        feature: 'Wall & Floor Tiles',
        classic: 'Upto ₹50 per sqft',
        pure: 'Upto ₹80 per sqft',
        premium: 'Upto ₹100 per sqft'
      },
      {
        feature: 'Sanitaryware & CP Fitting',
        classic: 'Upto ₹25,000 per bathroom',
        pure: 'Upto ₹50,000 per bathroom',
        premium: 'Upto ₹75,000 per bathroom'
      },
      {
        feature: 'CPVC Pipes',
        classic: 'Astral / Ashirwad',
        pure: 'Astral / Ashirwad',
        premium: 'Astral / Ashirwad'
      },
      {
        feature: 'Bathroom Doors',
        classic: 'Waterproof Flush Doors or WPC',
        pure: 'Waterproof Flush Doors or WPC',
        premium: 'Waterproof Flush Doors or WPC'
      },
      {
        feature: 'Provision',
        classic: 'Geyser and Solar Water Provision',
        pure: 'Geyser and Solar Water Provision',
        premium: 'Geyser and Solar Water Provision'
      }
    ]
  },
  {
    id: 'doors_windows',
    name: 'Doors & Windows',
    iconName: 'DoorClosed',
    items: [
      {
        feature: 'Windows',
        classic: 'UPVC with glass and mesh shutter (3 track with 1 mesh) – Lesso / Eiti',
        pure: 'UPVC with glass and mesh shutter (3 track with 1 mesh) – Prominance',
        premium: 'UPVC with glass and mesh shutter (3 track with 1 mesh) – Fenesta / Aluminium Sliding by Tostem'
      },
      {
        feature: 'Main Entrance Door',
        classic: 'Upto ₹20,000 – Flush Door',
        pure: 'Upto ₹40,000 – Teak Wood (PU) Finish',
        premium: 'Upto ₹50,000 – Teak Wood (PU) Finish'
      },
      {
        feature: 'Internal Doors',
        classic: 'Upto ₹12,000 (Laminate)',
        pure: 'Upto ₹20,000 (Laminate)',
        premium: 'Upto ₹35,000 – Veneer with PU Finish'
      },
      {
        feature: 'Pooja Room Door',
        classic: '—',
        pure: '1 Door Upto ₹15,000',
        premium: '1 Door Upto ₹20,000'
      }
    ]
  },
  {
    id: 'painting',
    name: 'Painting & Finishing',
    iconName: 'Paintbrush',
    items: [
      {
        feature: 'Interior Wall Painting',
        classic: 'JK Putty + Tractor Emulsion',
        pure: 'JK Putty + Apcolite Premium Emulsion',
        premium: 'JK Putty + Royale Luxury Emulsion'
      },
      {
        feature: 'Exterior Wall Painting',
        classic: 'Asian Primer + Apex Exterior Emulsion Paint',
        pure: 'Asian Primer + Apex Exterior Emulsion Paint',
        premium: 'Asian Primer + Apex Ultima Exterior Emulsion Paint'
      }
    ]
  },
  {
    id: 'flooring',
    name: 'Flooring & Finishes',
    iconName: 'Layers',
    items: [
      {
        feature: 'Living & Dining Area',
        classic: 'Tiles Upto ₹50 per sqft',
        pure: 'Tiles / Marble Upto ₹140 per sqft',
        premium: 'Tiles / Marble Upto ₹250 per sqft'
      },
      {
        feature: 'Rooms and Kitchen Flooring',
        classic: 'Tiles / Marble Upto ₹50 per sqft',
        pure: 'Tiles / Marble Upto ₹100 per sqft',
        premium: 'Tiles / Marble Upto ₹250 per sqft'
      },
      {
        feature: 'Balconies & Open Areas',
        classic: 'Anti-skid Tiles Upto ₹40 per sqft',
        pure: 'Anti-skid Tiles Upto ₹80 per sqft',
        premium: 'Anti-skid Tiles Upto ₹90 per sqft'
      },
      {
        feature: 'Staircase Flooring',
        classic: 'Granite Upto ₹70 per sqft',
        pure: 'Granite Upto ₹110 per sqft',
        premium: 'Granite Upto ₹140 per sqft'
      },
      {
        feature: 'Parking Tiles',
        classic: 'Anti-skid Tiles Upto ₹40 per sqft',
        pure: 'Anti-skid Tiles Upto ₹70 per sqft',
        premium: 'Anti-skid Tiles Upto ₹70 per sqft'
      }
    ]
  },
  {
    id: 'electrical',
    name: 'Electrical Infrastructure',
    iconName: 'Zap',
    items: [
      {
        feature: 'Wiring & Cables',
        classic: 'All wiring with fire proof wires – Finolex / Anchor / Havells',
        pure: 'All wiring with fire proof wires – Finolex / Anchor / Havells',
        premium: 'All wiring with fire proof wires – Finolex / Polycab / Havells'
      },
      {
        feature: 'Switches & Sockets',
        classic: 'Anchor / Roma',
        pure: 'Legrand Mylinc / Havells / Coral / Roma',
        premium: 'Schneider Unica Pure / Legrand Myrius / Jaquar'
      },
      {
        feature: 'Points Provision',
        classic: 'UPS / AC / WiFi / Geyser / Lift Provision',
        pure: 'UPS / AC / WiFi / Geyser',
        premium: 'UPS / AC / WiFi / Geyser'
      }
    ]
  },
  {
    id: 'miscellaneous',
    name: 'Civil & Structural Additions',
    iconName: 'Wrench',
    items: [
      {
        feature: 'Overhead Tank',
        classic: 'Sintex / Apollo double layered overhead tank of 2000L. Additional capacity at ₹9/L. Platform charged additionally.',
        pure: 'Sintex / Apollo double layered overhead tank of 2000L. Additional capacity at ₹9/L. Platform charged additionally.',
        premium: 'Sintex / Apollo double layered overhead tank of 2000L. Additional capacity at ₹9/L. Platform charged additionally.'
      },
      {
        feature: 'Underground Sump',
        classic: '3,000 Litres',
        pure: '7,000 Litres',
        premium: '8,000 Litres'
      },
      {
        feature: 'Staircase & Balcony Railings',
        classic: 'MS Railing',
        pure: 'SS (Stainless Steel) Railing – SS 304 Grade Profile',
        premium: 'SS (Stainless Steel) Railing – SS 304 Grade Profile'
      },
      {
        feature: 'Lift',
        classic: '—',
        pure: 'Upto ₹10 Lakhs',
        premium: 'Upto ₹12 Lakhs'
      }
    ]
  },
  {
    id: 'interior',
    name: 'Interior Enhancements',
    iconName: 'Sparkles',
    items: [
      {
        feature: 'Wardrobe',
        classic: 'As per design – Laminate finish HDHMR',
        pure: 'As per design – Laminate finish Upto ₹1,800 per sqft',
        premium: 'As per design – PU or Acrylic finish Upto ₹2,400 per sqft'
      },
      {
        feature: 'Washroom Vanity',
        classic: 'Upto ₹15,000',
        pure: 'Upto ₹25,000',
        premium: 'Upto ₹40,000'
      },
      {
        feature: 'Main Door Lock',
        classic: 'Digital Lock – ₹10,000',
        pure: 'Digital Lock – ₹15,000',
        premium: 'Digital Lock – ₹20,000'
      },
      {
        feature: 'False Ceiling',
        classic: 'As per design – Gypsum Boards or POP',
        pure: 'As per design – Gypsum Boards or POP',
        premium: 'As per design – Gypsum Boards or POP'
      },
      {
        feature: 'Fans and Lights',
        classic: 'As per design',
        pure: 'As per design',
        premium: 'As per design'
      }
    ]
  }
];
