import { ServiceDetail } from '../types';

export const servicesData: ServiceDetail[] = [
  {
    id: 'construction',
    title: 'Turnkey Construction',
    tagline: 'Precision structural engineering and premium-quality execution for residential and commercial builds.',
    description: 'Jain Properties and Developers offers end-to-end turnkey construction solutions across your region. From digital plot surveys and geotechnical soil testing to RCC structural frameworks and precision masonry work, we ensure uncompromising quality, strict safety compliance, and on-time project delivery without cost escalations.',
    icon: 'Building2',
    heroImage: '/images/construction.jpg',
    features: [
      { title: 'Seismic Structural Design', desc: 'RCC structures engineered in accordance with IS 1893 seismic design standards for applicable seismic zones.' },
      { title: 'Grade-A Certified Materials', desc: 'Direct sourcing of Tata Tiscon / JSW steel and UltraTech / Ambuja cement.' },
      { title: 'Advanced Waterproofing', desc: 'Multi-layer Dr. Fixit/Sika waterproofing systems designed to minimize seepage.' },
      { title: 'Strict Milestone Timelines', desc: 'Clearly defined milestone-based project schedules with contractual accountability.' }
    ],
    keyBenefits: [
      'Fixed-cost transparent contracts with zero hidden cost surprises',
      'Dedicated on-site site engineer & Project Manager monitoring daily mix ratios',
      'Concrete cube strength testing reports provided at every casting stage',
      'Complimentary architectural 2D floor plans & 3D exterior renderings'
    ],
    specifications: [
      'Fe 500D Grade Steel / Fe 550D Grade Steel Reinforcement',
      'M20 / M25 Controlled Design Concrete Mix',
      'First-Class Red Bricks / High-Density AAC Blocks',
      'CPVC Heavy-Duty Astral/Supreme Plumbing Networks',
      'Dr. Fixit Pidifin 2K Elastomeric Waterproofing'
    ]
  },
  {
    id: 'interiors',
    title: 'Bespoke Interiors',
    tagline: 'Luxury interior architecture, custom modular woodwork, & curated aesthetic styling.',
    description: 'Transforming raw structures into breathtaking living spaces. Our interior division merges architectural space planning with high-end craftsmanship—specializing in custom modular kitchens, veneer paneling, designer gypsum false ceilings, ambient magnetic track lighting, and luxury Italian marble flooring.',
    icon: 'Sparkles',
    heroImage: '/images/interiors.jpg',
    features: [
      { title: 'Custom Woodwork & Joinery', desc: 'Factory-finished HDMR wardrobes, veneer wall paneling & solid teak trims.' },
      { title: 'Modular Kitchen Systems', desc: 'Ergonomic layouts featuring Hettich / Hafele soft-close hardware & quartz tops.' },
      { title: 'Architectural Lighting Design', desc: 'Concealed LED coves, magnetic tracks, and warm ambient accent lights.' },
      { title: 'Luxury Flooring Cladding', desc: 'Precision Italian marble laying with diamond epoxy jointing.' }
    ],
    keyBenefits: [
      'Full 3D interior renders before execution so you see every detail',
      'Boiling Water Proof (BWP) and Termite-Resistant HDMR materials',
      'Seamless coordination between civil, electrical, and carpentry trades',
      'Post-handover maintenance warranty on hardware and finishes'
    ],
    specifications: [
      'Action TESA / Century HDMR Grade Boards',
      'Hettich / Hafele Soft-Close Blumotion Hardware',
      'Asian Paints Royale Luxury / PU Italian Finishes',
      'Dyna / Botticino Imported Italian Marble Cladding',
      'Concealed Architectural Magnetic Track Profiles'
    ]
  },
  {
    id: 'project-management',
    title: 'Project Management (PMC)',
    tagline: 'Third-party quality audits, cost control, vendor management and timeline assurance.',
    description: 'Build with complete peace of mind through our Project Management Consultancy (PMC) services. We act as your trusted technical representative on-site—overseeing contractors, enforcing strict material specifications, conducting rigorous quality audits, and managing project budgets and cost control to protect your investment.',
    icon: 'ClipboardCheck',
    heroImage: '/images/pmc.jpg',
    features: [
      { title: 'Technical Quality Audits', desc: 'Over 120 quality checkpoints.' },
      { title: 'Contractor & Vendor Management', desc: 'Handling multi-trade alignment, rate negotiations, and work certification.' },
      { title: 'Budget & Cost Control', desc: 'Verifying measurement sheets to minimize overbilling and material wastage.' },
      { title: 'Weekly Live Reporting', desc: 'Comprehensive progress tracking via digital portal and weekly video updates.' }
    ],
    keyBenefits: [
      'Eliminates vendor disputes, delays, and contractor trickery',
      'Saves up to 12-15% in overall project expenditure through value engineering',
      'Ensures full compliance with municipal drawings & structural safety codes',
      'Completely stress-free experience for NRI & busy homeowner clients'
    ],
    specifications: [
      'Over 120 Quality Checkpoints',
      'Concrete Slump & Cube Strength Lab Testing Certification',
      'Detailed Bill of Quantities (BOQ) Audit & Reconciliation',
      'Pre-Handover Master Snagging Inspection Dossier'
    ]
  }
];
