import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    name: 'Rajesh & Sangeeta Sharma',
    roleOrLocation: 'Your location',
    projectType: '500 Sq. Yd. Luxury Villa Construction',
    rating: 5,
    quote: 'Jain Properties and Developers took complete ownership of our villa construction. Our Team and Property Consultant managed everything from soil testing to structural engineering and final interior styling. The transparency in material selection and zero cost escalations made the whole journey completely stress-free!',
    image: '/images/avatar1.jpg'
  },
  {
    id: 't2',
    name: 'Vikram Malhotra & Family',
    roleOrLocation: 'Greater Kailash II, South Delhi',
    projectType: 'Turnkey Builder Floor & Luxury Interiors',
    rating: 5,
    quote: 'The weekly project management reports and stage-wise quality checks were outstanding. Unlike usual contractors who delay projects, Jain Properties and Developers delivered our South Delhi floor on schedule with immaculate finish quality.',
    image: '/images/avatar2.jpg'
  },
  {
    id: 't3',
    name: 'Siddharth Verma',
    roleOrLocation: 'Your location',
    projectType: 'Modern Duplex Penthouse Interiors',
    rating: 5,
    quote: 'Their interior craftsmanship, veneer paneling, and custom false ceiling design completely elevated our home. The package specifications were followed line-by-line without any hidden charges or substitute brands.',
    image: '/images/avatar3.jpg'
  },
  {
    id: 't4',
    name: 'Harish & Anita Mehra',
    roleOrLocation: 'Sector 44, Noida',
    projectType: 'Full Construction & Landscaping',
    rating: 5,
    quote: 'Having a dedicated Project Manager on site every single day made all the difference. They handled contractors, structural safety testing, and municipal approvals smoothly. Highly recommended for anyone building in NCR.',
    image: '/images/avatar4.jpg'
  }
];
