export interface PackageDetailItem {
  feature: string;
  classic: string;
  pure: string;
  premium: string;
}

export interface PackageCategory {
  id: string;
  name: string;
  iconName: string;
  items: PackageDetailItem[];
}

export interface PackageTier {
  id: 'classic' | 'pure' | 'premium';
  name: string;
  price: number;
  unit: string;
  tagline: string;
  badge?: string;
  highlightColor: string;
  summaryInclusions: string[];
}

export interface ProcessStage {
  step: number;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  deliverables: string[];
  durationEstimate?: string;
  keyMetric?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  roleOrLocation: string;
  projectType: string;
  rating: number;
  quote: string;
  image: string;
}

export interface ServiceDetail {
  id: string;
  title: string;
  tagline: string;
  description: string;
  icon: string;
  heroImage: string;
  features: { title: string; desc: string }[];
  keyBenefits: string[];
  specifications: string[];
}

export interface LeadFormData {
  name: string;
  phone: string;
  plotLocation: string;
  plotSize: string;
  serviceType?: string;
  packageInterest?: string;
  message?: string;
}
